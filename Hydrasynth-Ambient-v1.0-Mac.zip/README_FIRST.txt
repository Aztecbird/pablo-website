==========================================================
 HYDRASYNTH AMBIENT DECK — Granular & Microcosm Companion
 Created by Pablo Arellano
 https://www.pabloarellano.org
==========================================================

Thank you for your support!

HOW TO LAUNCH:
1. Double-click "Hydrasynth Ambient Deck.app" (or double-click "start.command").
2. Your web browser will open automatically to the companion dashboard at:
   http://localhost:8080
3. Allow MIDI device access if prompted by your browser (Chrome, Edge, or Brave recommended).
4. The controller will automatically connect to your ASM Hydrasynth over USB!
5. Select any of the 20 Curated Ambient Presets, play chords via the built-in Latch Pads, or morph sounds with the live XY Pad.

HARDWARE SETUP TIP (HYDRASYNTH):
To ensure full two-way control on your Hydrasynth hardware:
- Press [SYSTEM SETUP] -> navigate to Page 4 (MIDI).
- Set "Prog Chg RX" to ON.
- Set "Param RX" to CC (or CC+NRPN).

DAW INTEGRATION (LOGIC PRO):
- Check "hydrasynth_logic_scripter.js" for a ready-to-use Logic Pro MIDI FX plugin script!

CLI TERMINAL CONTROL:
- Advanced users can run: python3 hydrasynth_cli.py list

SUPPORT & QUESTIONS:
Email: aztecbird@mac.com
Website: https://www.pabloarellano.org
==========================================================
