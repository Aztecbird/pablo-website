#!/usr/bin/env python3
"""
Hydrasynth Terminal Shell CLI
Control Hydrasynth presets, cutoffs, macros, and panic directly from terminal!

Usage:
  python3 hydrasynth_cli.py preset <1-20>
  python3 hydrasynth_cli.py cutoff <0-127>
  python3 hydrasynth_cli.py space <0-127>
  python3 hydrasynth_cli.py panic
  python3 hydrasynth_cli.py list
"""

import sys
import time
import ctypes

coremidi = ctypes.cdll.LoadLibrary('/System/Library/Frameworks/CoreMIDI.framework/CoreMIDI')
corefoundation = ctypes.cdll.LoadLibrary('/System/Library/Frameworks/CoreFoundation.framework/CoreFoundation')

CFStringCreateWithCString = corefoundation.CFStringCreateWithCString
CFStringCreateWithCString.argtypes = [ctypes.c_void_p, ctypes.c_char_p, ctypes.c_uint]
CFStringCreateWithCString.restype = ctypes.c_void_p
kCFStringEncodingUTF8 = 0x08000100

class MIDIPacket(ctypes.Structure):
    _fields_ = [('timeStamp', ctypes.c_uint64),
                ('length', ctypes.c_uint16),
                ('data', ctypes.c_uint8 * 256)]

class MIDIPacketList(ctypes.Structure):
    _fields_ = [('numPackets', ctypes.c_uint32),
                ('packet', MIDIPacket * 1)]

def get_hydra_dest():
    num_dest = coremidi.MIDIGetNumberOfDestinations()
    kMIDIPropertyName = ctypes.c_void_p.in_dll(coremidi, 'kMIDIPropertyName')
    CFStringGetCString = corefoundation.CFStringGetCString
    CFStringGetCString.argtypes = [ctypes.c_void_p, ctypes.c_char_p, ctypes.c_long, ctypes.c_uint]
    CFStringGetCString.restype = ctypes.c_bool

    for i in range(num_dest):
        dest = coremidi.MIDIGetDestination(i)
        str_ref = ctypes.c_void_p()
        coremidi.MIDIObjectGetStringProperty(dest, kMIDIPropertyName, ctypes.byref(str_ref))
        buf = ctypes.create_string_buffer(256)
        CFStringGetCString(str_ref, buf, 256, kCFStringEncodingUTF8)
        name = buf.value.decode('utf-8', errors='ignore')
        if 'hydra' in name.lower():
            return dest, name
    if num_dest > 0:
        return coremidi.MIDIGetDestination(0), "Default Port"
    return None, None

def send_midi_bytes(bytes_list):
    dest, name = get_hydra_dest()
    if not dest:
        print("❌ Hydrasynth not detected on USB!")
        return False

    client = ctypes.c_void_p()
    out_port = ctypes.c_void_p()
    client_name = CFStringCreateWithCString(None, b'HydraCLI', kCFStringEncodingUTF8)
    port_name = CFStringCreateWithCString(None, b'Out', kCFStringEncodingUTF8)

    coremidi.MIDIClientCreate(client_name, None, None, ctypes.byref(client))
    coremidi.MIDIOutputPortCreate(client, port_name, ctypes.byref(out_port))

    packetList = MIDIPacketList()
    packetList.numPackets = 1
    packetList.packet[0].timeStamp = 0
    packetList.packet[0].length = len(bytes_list)
    for i, b in enumerate(bytes_list):
        packetList.packet[0].data[i] = b

    coremidi.MIDISend(out_port, dest, ctypes.byref(packetList))
    return True

PRESETS = {
    1: ("Nebula Cloud Pad", {16: 105, 17: 75, 18: 20, 19: 45, 20: 30, 21: 70, 22: 70, 23: 110, 74: 68, 71: 22}),
    2: ("Microcosm Mosaic", {16: 65, 17: 90, 18: 115, 19: 80, 20: 35, 21: 105, 22: 15, 23: 115, 74: 95, 71: 45}),
    3: ("Abyssal Drone", {16: 110, 17: 85, 18: 15, 19: 55, 20: 50, 21: 40, 22: 90, 23: 75, 74: 42, 71: 60}),
    4: ("Glass Aurora", {16: 95, 17: 68, 18: 35, 19: 85, 20: 15, 21: 127, 22: 10, 23: 95, 74: 108, 71: 30}),
    5: ("Tape Memory 1984", {16: 55, 17: 80, 18: 30, 19: 60, 20: 120, 21: 45, 22: 45, 23: 65, 74: 58, 71: 38}),
    6: ("Solar Wind", {16: 118, 17: 88, 18: 45, 19: 90, 20: 60, 21: 85, 22: 95, 23: 105, 74: 82, 71: 65}),
    7: ("Bioluminescence", {16: 90, 17: 85, 18: 80, 19: 70, 20: 30, 21: 95, 22: 30, 23: 120, 74: 88, 71: 35}),
    8: ("Ethereal Voices", {16: 100, 17: 60, 18: 25, 19: 95, 20: 35, 21: 64, 22: 80, 23: 85, 74: 72, 71: 28}),
    9: ("Dark Matter Sub", {16: 85, 17: 65, 18: 20, 19: 40, 20: 75, 21: 20, 22: 95, 23: 60, 74: 36, 71: 50}),
    10: ("Celestial Choir", {16: 125, 17: 70, 18: 15, 19: 50, 20: 20, 21: 80, 22: 85, 23: 120, 74: 76, 71: 18}),
    11: ("Shoegaze Horizon", {16: 115, 17: 95, 18: 50, 19: 80, 20: 85, 21: 75, 22: 65, 23: 127, 74: 84, 71: 40}),
    12: ("Raindrop Granules", {16: 80, 17: 90, 18: 105, 19: 65, 20: 25, 21: 90, 22: 10, 23: 125, 74: 98, 71: 42}),
    13: ("Submerged Cathedral", {16: 127, 17: 80, 18: 10, 19: 35, 20: 45, 21: 30, 22: 90, 23: 90, 74: 52, 71: 32}),
    14: ("Frozen Shimmer", {16: 120, 17: 85, 18: 40, 19: 100, 20: 20, 21: 125, 22: 50, 23: 100, 74: 102, 71: 25}),
    15: ("Midnight Tape Reel", {16: 60, 17: 78, 18: 35, 19: 55, 20: 125, 21: 50, 22: 40, 23: 70, 74: 62, 71: 30}),
    16: ("Cosmic Strummer", {16: 92, 17: 88, 18: 95, 19: 75, 20: 40, 21: 85, 22: 20, 23: 110, 74: 92, 71: 38}),
    17: ("Crystalline Cavern", {16: 105, 17: 92, 18: 60, 19: 90, 20: 50, 21: 110, 22: 35, 23: 105, 74: 86, 71: 48}),
    18: ("Warm Oberheim Bloom", {16: 75, 17: 60, 18: 10, 19: 40, 20: 45, 21: 50, 22: 60, 23: 85, 74: 70, 71: 22}),
    19: ("Quantum Haze", {16: 115, 17: 75, 18: 45, 19: 60, 20: 80, 21: 65, 22: 95, 23: 90, 74: 64, 71: 25}),
    20: ("Infinity Space Drone", {16: 127, 17: 105, 18: 30, 19: 50, 20: 65, 21: 75, 22: 85, 23: 115, 74: 74, 71: 20})
}

def main():
    if len(sys.argv) < 2:
        print(__doc__)
        return

    cmd = sys.argv[1].lower()

    if cmd == "list":
        print("\n🌌 20 Available Ambient Soundscapes:")
        for k, v in PRESETS.items():
            print(f"  [{k:02d}] {v[0]}")
        print("\nUsage: python3 hydrasynth_cli.py preset <number>")

    elif cmd == "preset":
        if len(sys.argv) < 3:
            print("Please specify a preset number (1-20). Example: python3 hydrasynth_cli.py preset 4")
            return
        p_num = int(sys.argv[2])
        if p_num in PRESETS:
            name, cc_map = PRESETS[p_num]
            print(f"✨ Injecting Preset #{p_num}: {name} into Hydrasynth...")
            for cc, val in cc_map.items():
                send_midi_bytes([0xB0, cc, val])
                time.sleep(0.005)
            print("✅ Done!")
        else:
            print("Invalid preset number. Choose 1 to 20.")

    elif cmd == "cutoff":
        val = int(sys.argv[2]) if len(sys.argv) > 2 else 75
        val = max(0, min(127, val))
        send_midi_bytes([0xB0, 74, val])
        print(f"🎛️ Filter Cutoff set to {val}")

    elif cmd == "space":
        val = int(sys.argv[2]) if len(sys.argv) > 2 else 80
        val = max(0, min(127, val))
        send_midi_bytes([0xB0, 16, val])
        print(f"🌌 Space / Reverb set to {val}")

    elif cmd == "panic":
        send_midi_bytes([0xB0, 123, 0])
        send_midi_bytes([0xB0, 120, 0])
        print("🛑 All Notes Off sent.")

    else:
        print(__doc__)

if __name__ == "__main__":
    main()
