/**
 * Hydrasynth Microcosm Ambient Glitch & Space Engine (Logic Pro Scripter)
 * 
 * Instructions:
 * 1. On your Hydrasynth MIDI Track in Logic Pro, click on "MIDI FX" slot.
 * 2. Select "Scripter".
 * 3. Paste this script into the editor and click "Run Script".
 */

// Controls defined in Logic's Scripter UI
var PluginParameters = [
  { name: "Microcosm Mode", type: "menu", valueStrings: ["Manual / Custom", "Mosaic Glitch", "Haze Cloud", "Crystal Shimmer", "Tape Flutter", "Infinite Freeze"], defaultValue: 1 },
  { name: "Space / Reverb (M1)", type: "lin", minValue: 0, maxValue: 127, numberOfSteps: 127, defaultValue: 80 },
  { name: "Delay Feedback (M2)", type: "lin", minValue: 0, maxValue: 127, numberOfSteps: 127, defaultValue: 70 },
  { name: "Glitch / Step Depth (M3)", type: "lin", minValue: 0, maxValue: 127, numberOfSteps: 127, defaultValue: 40 },
  { name: "Mutant Morph (M4)", type: "lin", minValue: 0, maxValue: 127, numberOfSteps: 127, defaultValue: 45 },
  { name: "Random Velocity Glitch", type: "checkbox", defaultValue: 1 },
  { name: "Glitch Probability (%)", type: "lin", minValue: 0, maxValue: 100, numberOfSteps: 100, defaultValue: 35 },
  { name: "Filter Cutoff (CC74)", type: "lin", minValue: 0, maxValue: 127, numberOfSteps: 127, defaultValue: 85 }
];

function ParameterChanged(param, value) {
  var ccMsg = new ControlChange();
  
  // Microcosm Preset Modes
  if (param === 0) {
    if (value === 1) { // Mosaic Glitch
      sendMacro(16, 65); // Space
      sendMacro(17, 85); // Delay FB
      sendMacro(18, 110); // Glitch
      sendMacro(19, 70); // Mutant
      sendCC(74, 95);    // Cutoff
    } else if (value === 2) { // Haze Cloud
      sendMacro(16, 115);
      sendMacro(17, 75);
      sendMacro(18, 20);
      sendMacro(19, 50);
      sendCC(74, 60);
    } else if (value === 3) { // Crystal Shimmer
      sendMacro(16, 95);
      sendMacro(17, 65);
      sendMacro(18, 40);
      sendMacro(19, 90);
      sendCC(74, 110);
    } else if (value === 4) { // Tape Flutter
      sendMacro(16, 50);
      sendMacro(17, 80);
      sendMacro(18, 30);
      sendMacro(19, 60);
      sendCC(74, 65);
    } else if (value === 5) { // Infinite Freeze
      sendMacro(16, 127);
      sendMacro(17, 100);
      sendMacro(18, 15);
      sendMacro(19, 30);
      sendCC(74, 75);
    }
  } else if (param === 1) {
    sendMacro(16, value);
  } else if (param === 2) {
    sendMacro(17, value);
  } else if (param === 3) {
    sendMacro(18, value);
  } else if (param === 4) {
    sendMacro(19, value);
  } else if (param === 7) {
    sendCC(74, value);
  }
}

function sendMacro(macroCC, val) {
  var cc = new ControlChange();
  cc.number = macroCC;
  cc.value = Math.floor(val);
  cc.send();
}

function sendCC(ccNumber, val) {
  var cc = new ControlChange();
  cc.number = ccNumber;
  cc.value = Math.floor(val);
  cc.send();
}

// Intercept MIDI notes from your Logic sequence to add Microcosm micro-variations
function HandleMIDI(event) {
  if (event instanceof NoteOn) {
    var randGlitch = GetParameter("Random Velocity Glitch");
    var prob = GetParameter("Glitch Probability (%)");

    if (randGlitch && Math.random() * 100 < prob) {
      // Micro-burst velocity & pitch variation
      event.velocity = Math.min(127, Math.max(20, event.velocity + Math.floor((Math.random() - 0.5) * 40)));
      
      // Send instantaneous Microcosm glitch CC burst
      var glitchCC = new ControlChange();
      glitchCC.number = 18; // Macro 3
      glitchCC.value = Math.floor(Math.random() * 127);
      glitchCC.send();
    }
  }
  
  event.send();
}
