// Microcosm AI Frontend Controller & Dynamic Rules Engine

const CC_MIX = 28;
const CC_SPACE = 29;
const CC_FILTER = 30;

// State
let ws = null;
let isEnabled = false;
let isPaused = false;

// Hardware snapshots
const defaultSnapshot = {
  mix: 64,
  filter: 64,
  space: 51
};

let currentValues = { ...defaultSnapshot };
let targetValues = { ...defaultSnapshot };

// Active Rule Structure
let activeRule = {
  mode: "COMBINE",
  explanation: "Listening for keyboard dynamics: soft piano playing expands Space (Reverb) to 105. Busy passages gently restrain Mix to maintain clarity. Filter slowly darkens over 60s.",
  ranges: {
    mix: { min: 20, max: 95, currentTarget: 64 },
    filter: { min: 30, max: 120, currentTarget: 64 },
    space: { min: 15, max: 110, currentTarget: 51 }
  },
  evolve: {
    enabled: true,
    targetParam: "filter",
    direction: -1,
    durationSec: 60,
    startTime: Date.now()
  },
  follow: {
    quietVelocityThreshold: 55,
    busyDensityThreshold: 4
  }
};

let recentNotes = [];
let lastVelocity = 0;

let audioCtx = null;
let analyser = null;
let micSource = null;
let isAudioActive = false;
let audioRms = 0;

const statusDot = document.getElementById('statusDot');
const statusText = document.getElementById('statusText');
const destSelect = document.getElementById('destSelect');
const srcSelect = document.getElementById('srcSelect');
const channelSelect = document.getElementById('channelSelect');

const enableBtn = document.getElementById('enableBtn');
const enableLabel = document.getElementById('enableLabel');
const enableIcon = document.getElementById('enableIcon');
const pauseBtn = document.getElementById('pauseBtn');
const restoreBtn = document.getElementById('restoreBtn');

const promptInput = document.getElementById('promptInput');
const applyPromptBtn = document.getElementById('applyPromptBtn');
const planExplanation = document.getElementById('planExplanation');
const planMode = document.getElementById('planMode');

const sliderMix = document.getElementById('sliderMix');
const sliderFilter = document.getElementById('sliderFilter');
const sliderSpace = document.getElementById('sliderSpace');

const valMix = document.getElementById('valMix');
const valFilter = document.getElementById('valFilter');
const valSpace = document.getElementById('valSpace');

const actMix = document.getElementById('actMix');
const actFilter = document.getElementById('actFilter');
const actSpace = document.getElementById('actSpace');

const hudMidiIn = document.getElementById('hudMidiIn');
const hudDensity = document.getElementById('hudDensity');
const hudEngine = document.getElementById('hudEngine');

const enableAudioBtn = document.getElementById('enableAudioBtn');
const audioMeterFill = document.getElementById('audioMeterFill');
const audioRmsText = document.getElementById('audioRmsText');

if (enableAudioBtn) {
  enableAudioBtn.addEventListener('click', async () => {
    if (!isAudioActive) {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true, video: false });
        audioCtx = new (window.AudioContext || window.webkitAudioContext)();
        analyser = audioCtx.createAnalyser();
        analyser.fftSize = 512;
        micSource = audioCtx.createMediaStreamSource(stream);
        micSource.connect(analyser);

        isAudioActive = true;
        enableAudioBtn.innerText = '🎙 Audio Active';
        enableAudioBtn.style.background = 'rgba(16, 185, 129, 0.2)';
        enableAudioBtn.style.borderColor = '#10b981';
        processAudio();
      } catch (err) {
        console.error('Microphone/Interface audio permission error:', err);
      }
    }
  });
}

function processAudio() {
  if (!isAudioActive || !analyser) return;
  const data = new Uint8Array(analyser.frequencyBinCount);
  analyser.getByteTimeDomainData(data);

  let sum = 0;
  for (let i = 0; i < data.length; i++) {
    const val = (data[i] - 128) / 128;
    sum += val * val;
  }
  const rms = Math.sqrt(sum / data.length);
  audioRms = rms;

  const pct = Math.min(100, Math.round(rms * 300));
  if (audioMeterFill) audioMeterFill.style.width = `${pct}%`;
  const db = (20 * Math.log10(rms || 0.0001)).toFixed(1);
  if (audioRmsText) audioRmsText.innerText = `${db} dB`;

  requestAnimationFrame(processAudio);
}

function initWebSocket() {
  const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
  ws = new WebSocket(`${protocol}//${window.location.host}`);

  ws.onopen = () => {
    statusDot.classList.add('online');
    statusText.innerText = 'Connected (CoreMIDI Live)';
    // Request fresh device list
    ws.send(JSON.stringify({ type: 'refresh_devices' }));
  };

  ws.onclose = () => {
    statusDot.classList.remove('online');
    statusText.innerText = 'Reconnecting Engine...';
    setTimeout(initWebSocket, 2000);
  };

  ws.onmessage = (event) => {
    try {
      const data = JSON.parse(event.data);
      handleMessage(data);
    } catch (e) {
      console.error("WS Parse error:", e);
    }
  };
}

function handleMessage(msg) {
  if (msg.type === 'devices') {
    populateDevices(msg.destinations, msg.sources);
  } else if (msg.type === 'note_on') {
    handleNoteOn(msg.note, msg.velocity);
  } else if (msg.type === 'status') {
    hudEngine.innerText = msg.msg;
  }
}

function populateDevices(destinations, sources) {
  destSelect.innerHTML = '';
  srcSelect.innerHTML = '';

  destinations.forEach((d) => {
    const opt = document.createElement('option');
    opt.value = d.id;
    opt.innerText = `[${d.id}] ${d.name}`;
    if (d.name.toLowerCase().includes('umc1820')) opt.selected = true;
    destSelect.appendChild(opt);
  });

  sources.forEach((s) => {
    const opt = document.createElement('option');
    opt.value = s.id;
    opt.innerText = `[${s.id}] ${s.name}`;
    if (s.name.toLowerCase().includes('casio')) {
      opt.selected = true;
    }
    srcSelect.appendChild(opt);
  });

  updatePorts();
}

function updatePorts() {
  if (!ws || ws.readyState !== WebSocket.OPEN) return;
  ws.send(JSON.stringify({
    type: 'select_ports',
    dest: parseInt(destSelect.value, 10) || 0,
    src: parseInt(srcSelect.value, 10) || 0,
    channel: parseInt(channelSelect.value, 10) || 0
  }));
}

destSelect.addEventListener('change', updatePorts);
srcSelect.addEventListener('change', updatePorts);
channelSelect.addEventListener('change', updatePorts);

function sendCC(cc, val) {
  if (!ws || ws.readyState !== WebSocket.OPEN) return;
  ws.send(JSON.stringify({
    type: 'send_cc',
    cc: cc,
    value: Math.round(val),
    channel: parseInt(channelSelect.value, 10) || 0
  }));
}

function handleNoteOn(note, velocity) {
  const now = Date.now();
  recentNotes.push({ time: now, vel: velocity });
  lastVelocity = velocity;

  hudMidiIn.innerText = `Key #${note} • Velocity ${velocity}`;

  if (!isEnabled || isPaused) return;

  applyAdaptiveRules(velocity);
}

function applyAdaptiveRules(velocity) {
  if (velocity < activeRule.follow.quietVelocityThreshold) {
    const factor = (activeRule.follow.quietVelocityThreshold - velocity) / activeRule.follow.quietVelocityThreshold;
    targetValues.space = activeRule.ranges.space.min + factor * (activeRule.ranges.space.max - activeRule.ranges.space.min);
  } else {
    targetValues.space = defaultSnapshot.space;
  }

  if (velocity > 85) {
    targetValues.mix = activeRule.ranges.mix.min + 15;
  } else {
    targetValues.mix = defaultSnapshot.mix;
  }
}

// Background Evolve & Parameter Smoothing Loop (runs at 40Hz = 25ms per step)
setInterval(() => {
  const now = Date.now();

  recentNotes = recentNotes.filter(n => now - n.time < 1500);
  const density = (recentNotes.length / 1.5).toFixed(1);
  hudDensity.innerText = `Last Vel: ${lastVelocity || '--'} | Density: ${density} notes/s`;

  if (isEnabled && !isPaused) {
    if (activeRule.evolve && activeRule.evolve.enabled) {
      const elapsed = (now - activeRule.evolve.startTime) / 1000;
      const progress = Math.min(1.0, elapsed / activeRule.evolve.durationSec);

      if (activeRule.evolve.targetParam === 'filter') {
        const start = activeRule.ranges.filter.max;
        const end = activeRule.ranges.filter.min;
        targetValues.filter = start + progress * (end - start);
      }
    }

    if (isAudioActive && audioRms > 0.15) {
      targetValues.mix = Math.max(activeRule.ranges.mix.min, targetValues.mix - 10);
    }

    const smoothFactor = 0.08;
    let changed = false;

    ['mix', 'filter', 'space'].forEach(param => {
      const diff = targetValues[param] - currentValues[param];
      if (Math.abs(diff) > 0.5) {
        currentValues[param] += diff * smoothFactor;
        changed = true;
      }
    });

    if (changed) {
      updateUI();
      sendCC(CC_MIX, currentValues.mix);
      sendCC(CC_FILTER, currentValues.filter);
      sendCC(CC_SPACE, currentValues.space);
    }
  }
}, 25);

function updateUI() {
  valMix.innerHTML = `${Math.round((currentValues.mix / 127) * 100)}<span>%</span>`;
  valFilter.innerHTML = `${Math.round(currentValues.filter)}`;
  valSpace.innerHTML = `${Math.round((currentValues.space / 127) * 100)}<span>%</span>`;

  sliderMix.value = currentValues.mix;
  sliderFilter.value = currentValues.filter;
  sliderSpace.value = currentValues.space;

  actMix.style.width = `${(currentValues.mix / 127) * 100}%`;
  actFilter.style.width = `${(currentValues.filter / 127) * 100}%`;
  actSpace.style.width = `${(currentValues.space / 127) * 100}%`;
}

sliderMix.addEventListener('input', (e) => {
  currentValues.mix = parseFloat(e.target.value);
  targetValues.mix = currentValues.mix;
  valMix.innerHTML = `${Math.round((currentValues.mix / 127) * 100)}<span>%</span>`;
  sendCC(CC_MIX, currentValues.mix);
});

sliderFilter.addEventListener('input', (e) => {
  currentValues.filter = parseFloat(e.target.value);
  targetValues.filter = currentValues.filter;
  valFilter.innerHTML = `${Math.round(currentValues.filter)}`;
  sendCC(CC_FILTER, currentValues.filter);
});

sliderSpace.addEventListener('input', (e) => {
  currentValues.space = parseFloat(e.target.value);
  targetValues.space = currentValues.space;
  valSpace.innerHTML = `${Math.round((currentValues.space / 127) * 100)}<span>%</span>`;
  sendCC(CC_SPACE, currentValues.space);
});

enableBtn.addEventListener('click', () => {
  isEnabled = !isEnabled;
  if (isEnabled) {
    isPaused = false;
    enableBtn.classList.add('running');
    enableIcon.innerText = '◼';
    enableLabel.innerText = 'Stop Automation';
    pauseBtn.innerText = '⏸ Pause';
    activeRule.evolve.startTime = Date.now();
    hudEngine.innerText = 'Active: Following & Evolving';
  } else {
    enableBtn.classList.remove('running');
    enableIcon.innerText = '▶';
    enableLabel.innerText = 'Enable Follow';
    hudEngine.innerText = 'Automation Stopped';
  }
});

pauseBtn.addEventListener('click', () => {
  if (!isEnabled) return;
  isPaused = !isPaused;
  if (isPaused) {
    pauseBtn.innerText = '▶ Resume';
    hudEngine.innerText = 'Paused: CC values frozen';
  } else {
    pauseBtn.innerText = '⏸ Pause';
    hudEngine.innerText = 'Resumed active automation';
  }
});

restoreBtn.addEventListener('click', () => {
  currentValues = { ...defaultSnapshot };
  targetValues = { ...defaultSnapshot };
  updateUI();
  sendCC(CC_MIX, defaultSnapshot.mix);
  sendCC(CC_FILTER, defaultSnapshot.filter);
  sendCC(CC_SPACE, defaultSnapshot.space);
  hudEngine.innerText = 'Restored starting baseline snapshot';
});

function interpretPrompt(text) {
  const lower = text.toLowerCase();
  let mode = "FOLLOW";
  let explanation = "";

  let rMix = { min: 25, max: 90 };
  let rFilter = { min: 30, max: 120 };
  let rSpace = { min: 20, max: 115 };
  let evolveConfig = { enabled: false, targetParam: 'filter', durationSec: 60, startTime: Date.now() };

  if (lower.includes('darken') || lower.includes('sweep') || lower.includes('gradually') || lower.includes('evolve')) {
    mode = lower.includes('quiet') || lower.includes('play') || lower.includes('velocity') ? "COMBINE" : "EVOLVE";
    evolveConfig.enabled = true;
    evolveConfig.durationSec = 60;
  }

  if (lower.includes('quiet') || lower.includes('spacious') || lower.includes('reverb')) {
    explanation += "Quiet playing opens up Space (Reverb). ";
    rSpace.max = 118;
  }

  if (lower.includes('busy') || lower.includes('gentle') || lower.includes('dense')) {
    explanation += "Busy or louder passages back off the Mix to preserve clarity. ";
    rMix.min = 20;
    rMix.max = 75;
  }

  if (evolveConfig.enabled) {
    explanation += "Filter gradually evolves lower over 60 seconds.";
  }

  if (!explanation) {
    explanation = "Adaptive follow active for Mix, Space, and Filter based on playing dynamics.";
  }

  return {
    mode: mode,
    explanation: explanation,
    ranges: { mix: rMix, filter: rFilter, space: rSpace },
    evolve: evolveConfig,
    follow: {
      quietVelocityThreshold: 55,
      busyDensityThreshold: 4
    }
  };
}

applyPromptBtn.addEventListener('click', () => {
  const text = promptInput.value.trim();
  if (!text) return;
  activeRule = interpretPrompt(text);
  planMode.innerText = `MODE: ${activeRule.mode}`;
  planExplanation.innerText = activeRule.explanation;

  document.getElementById('minMix').innerText = activeRule.ranges.mix.min;
  document.getElementById('maxMix').innerText = activeRule.ranges.mix.max;
  document.getElementById('minFilter').innerText = activeRule.ranges.filter.min;
  document.getElementById('maxFilter').innerText = activeRule.ranges.filter.max;
  document.getElementById('minSpace').innerText = activeRule.ranges.space.min;
  document.getElementById('maxSpace').innerText = activeRule.ranges.space.max;
});

window.setPresetPrompt = function(presetKey) {
  if (presetKey === 'spacious_ambient') {
    promptInput.value = "Quiet playing produces a more spacious texture, keep the effect gentle";
  } else if (presetKey === 'gentle_busy') {
    promptInput.value = "Keep the effect gentle during busy passages, with subtle reverb response";
  } else if (presetKey === 'slow_darken') {
    promptInput.value = "Gradually darken sustained textures over one minute";
  } else if (presetKey === 'dynamic_trio') {
    promptInput.value = "Quiet playing produces spacious reverb, keep effect gentle during busy passages, gradually darken filter";
  }
  applyPromptBtn.click();
};

initWebSocket();
updateUI();
