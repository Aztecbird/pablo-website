/**
 * Torso S4 MIDI Parameter Controller & Automation Loop Recorder
 * Client-side script handling Web MIDI, custom UI interactions, presets, and looping automation.
 */

// --- Constants & Config ---
const DEFAULT_PRESET_NAME = "Default Init State";
const MIDICC = {
  LEVEL: 56,
  CUTOFF: 78,
  SENDS: [10, 11, 12, 13],
  ENCODERS: [14, 15, 16, 17, 18],
  MATERIAL: {
    speed: 46,
    start: 48,
    length: 49
  },
  GRANULAR: {
    pitch: 62,
    rate: 63,
    size: 64,
    contour: 65,
    warp: 66,
    spray: 67
  },
  FILTER: {
    cutoff: 78,
    resonance: 79,
    decay: 80,
    pitch: 81,
    slope: 82
  },
  COLOUR: {
    drive: 94,
    compress: 95,
    crush: 96
  },
  SPACE: {
    delayAmt: 110,
    delayTime: 111,
    delayFeedback: 114,
    tone: 116,
    reverbAmt: 112,
    reverbSize: 113,
    reverbDecay: 117,
    spread: 115
  }
};

const MICROCOSM_CC = {
  activity: 6,
  shape: 7,
  filter: 8,
  mix: 9,
  time: 10,
  repeats: 11,
  space: 12,
  loopLevel: 13,
  modRate: 14,
  modDepth: 19,
  reverbTime: 20,
  bypass: 102
};

const DEFAULT_TRACK_PARAMS = () => ({
  // Mix page
  level: 100,
  cutoff: 64,
  pan: 64, // Track Panning
  send1: 0,
  send2: 0,
  send3: 0,
  send4: 0,
  // Material page
  speed: 64,
  start: 0,
  length: 127,
  // Granular page
  gPitch: 64,
  gRate: 64,
  gSize: 64,
  gContour: 64,
  gWarp: 0,
  gSpray: 0,
  // Filter page
  resonance: 0,
  decay: 64,
  fPitch: 64,
  slope: 0,
  // Colour page
  drive: 0,
  compress: 0,
  crush: 0,
  // Space page
  delayAmt: 0,
  delayTime: 64,
  delayFeedback: 0,
  reverbAmt: 0,
  reverbSize: 64,
  reverbDecay: 64,
  tone: 64,
  spread: 64,
  
  // Track Status
  muted: false,
  soloed: false,
  activeTab: "mix",
  
  // Automation Local Status
  isRecording: false,
  isPlaybackActive: true,
  automationEvents: [] // Array of { time: ms, paramName: string, value: number }
});

// --- Application State ---
const state = {
  midiAccess: null,
  midiOutput: null,
  microcosmOutput: null,
  presets: [],
  activePresetIndex: -1, // -1 means default init
  tracks: [
    { id: 1, midiChannel: 1, ...DEFAULT_TRACK_PARAMS() },
    { id: 2, midiChannel: 2, ...DEFAULT_TRACK_PARAMS() },
    { id: 3, midiChannel: 3, ...DEFAULT_TRACK_PARAMS() },
    { id: 4, midiChannel: 4, ...DEFAULT_TRACK_PARAMS() }
  ],
  microcosm: {
    midiChannel: 1, // default MIDI Channel (can be 1-16 or 'ALL')
    activity: 0,
    shape: 0,
    filter: 64,
    mix: 64,
    time: 64,
    repeats: 64,
    space: 0,
    loopLevel: 64,
    modRate: 0,
    modDepth: 0,
    reverbTime: 64,
    bypass: false, // false = engaged, true = bypassed
    preset: 1, // PC 1-60
    isRecording: false,
    isPlaybackActive: true,
    automationEvents: []
  }
};

// --- Global Transport Engine ---
const transport = {
  isPlaying: false,
  bpm: 120,
  loopBars: 16,
  playheadMs: 0,
  totalDurationMs: 0,
  lastTickTime: 0
};

// --- DOM Elements Cache ---
const el = {
  midiIndicator: document.getElementById('midi-indicator'),
  midiStatusText: document.getElementById('midi-status-text'),
  midiDeviceSelect: document.getElementById('midi-device-select'),
  microcosmDeviceSelect: document.getElementById('microcosm-device-select'),
  presetSelect: document.getElementById('preset-select'),
  newPresetName: document.getElementById('new-preset-name'),
  savePresetBtn: document.getElementById('save-preset-btn'),
  deletePresetBtn: document.getElementById('delete-preset-btn'),
  exportPresetBtn: document.getElementById('export-preset-btn'),
  importPresetFile: document.getElementById('import-preset-file'),
  tracksGrid: document.getElementById('tracks-grid'),
  notification: document.getElementById('notification'),
  
  // Transport controls
  globalPlayBtn: document.getElementById('global-play-btn'),
  panicBtn: document.getElementById('panic-btn'),
  globalBpm: document.getElementById('global-bpm'),
  globalBpmVal: document.getElementById('global-bpm-val'),
  globalLoopBars: document.getElementById('global-loop-bars'),
  timelinePlayhead: document.getElementById('timeline-playhead')
};

// --- Initialization ---
document.addEventListener('DOMContentLoaded', () => {
  updateLoopDuration();
  initMidi();
  loadLocalPresets();
  renderTracks();
  setupGlobalEvents();
});

// --- Global Transport & Recording Loop ---
function updateLoopDuration() {
  const beatDurationMs = 60000 / transport.bpm;
  const barDurationMs = 4 * beatDurationMs; // assume 4/4
  transport.totalDurationMs = transport.loopBars * barDurationMs;
}

let animationFrameId = null;
let midiClockIntervalId = null;

function startMidiClock() {
  stopMidiClock();
  
  // Send MIDI Start command (0xFA) to both S4 and Microcosm
  if (state.midiOutput) {
    try { state.midiOutput.send([0xFA]); } catch (e) { console.error("Error sending S4 MIDI Start:", e); }
  }
  if (state.microcosmOutput) {
    try { state.microcosmOutput.send([0xFA]); } catch (e) { console.error("Error sending Microcosm MIDI Start:", e); }
  }
  
  // 24 ticks per beat (PPQ = 24)
  let nextTickTime = performance.now();
  
  function sendTickLoop() {
    if (!transport.isPlaying) return;
    
    const now = performance.now();
    while (now >= nextTickTime) {
      // Send clock tick (0xF8)
      if (state.midiOutput) {
        try { state.midiOutput.send([0xF8]); } catch (e) {}
      }
      if (state.microcosmOutput) {
        try { state.microcosmOutput.send([0xF8]); } catch (e) {}
      }
      nextTickTime += (60000 / transport.bpm) / 24;
    }
    
    // Schedule next check quickly (every 4ms) to maintain precision
    midiClockIntervalId = setTimeout(sendTickLoop, 4);
  }
  
  sendTickLoop();
}

function stopMidiClock() {
  if (midiClockIntervalId) {
    clearTimeout(midiClockIntervalId);
    midiClockIntervalId = null;
  }
  // Send MIDI Stop command (0xFC) to both S4 and Microcosm
  if (state.midiOutput) {
    try { state.midiOutput.send([0xFC]); } catch (e) {}
  }
  if (state.microcosmOutput) {
    try { state.microcosmOutput.send([0xFC]); } catch (e) {}
  }
}

function tick(now) {
  if (!transport.isPlaying) {
    animationFrameId = null;
    return;
  }

  if (!transport.lastTickTime) {
    transport.lastTickTime = now;
  }

  const delta = now - transport.lastTickTime;
  transport.lastTickTime = now;

  const lastPlayhead = transport.playheadMs;
  let nextPlayhead = transport.playheadMs + delta;

  let wrapped = false;
  if (nextPlayhead >= transport.totalDurationMs) {
    nextPlayhead = nextPlayhead % transport.totalDurationMs;
    wrapped = true;
  }

  transport.playheadMs = nextPlayhead;

  // Update visual timeline indicator
  updateTimelineUI();

  // Run event playback engine
  playbackAutomation(lastPlayhead, nextPlayhead, wrapped);

  animationFrameId = requestAnimationFrame(tick);
}

function updateTimelineUI() {
  if (el.timelinePlayhead) {
    const percentage = (transport.playheadMs / transport.totalDurationMs) * 100;
    el.timelinePlayhead.style.left = `${percentage}%`;
  }
}

function toggleTransport() {
  transport.isPlaying = !transport.isPlaying;
  
  if (transport.isPlaying) {
    el.globalPlayBtn.classList.add('active');
    el.globalPlayBtn.innerHTML = '<span class="play-icon">■</span> STOP';
    transport.lastTickTime = performance.now();
    animationFrameId = requestAnimationFrame(tick);
    
    // Start high-precision MIDI clock and send Start command
    startMidiClock();
  } else {
    el.globalPlayBtn.classList.remove('active');
    el.globalPlayBtn.innerHTML = '<span class="play-icon">▶</span> PLAY';
    if (animationFrameId) {
      cancelAnimationFrame(animationFrameId);
      animationFrameId = null;
    }
    
    // Stop MIDI clock and send Stop command
    stopMidiClock();
    
    // Stop recording on all tracks when stopping playhead
    state.tracks.forEach(track => {
      if (track.isRecording) {
        toggleTrackRecord(track.id);
      }
    });

    // Stop recording on Microcosm when stopping playhead
    if (state.microcosm.isRecording) {
      toggleMicrocosmRecord();
    }
  }
}

// --- Automation Playback Parser ---
function playbackAutomation(lastTime, currentTime, wrapped) {
  state.tracks.forEach(track => {
    if (!track.isPlaybackActive || track.automationEvents.length === 0) return;

    let events = [];
    if (!wrapped) {
      // Normal range
      events = track.automationEvents.filter(e => e.time >= lastTime && e.time < currentTime);
    } else {
      // Wrapped range (play rest of loop + beginning of loop)
      events = track.automationEvents.filter(e => e.time >= lastTime && e.time <= transport.totalDurationMs)
                .concat(track.automationEvents.filter(e => e.time >= 0 && e.time < currentTime));
    }

    events.forEach(evt => {
      // Update state parameter silently
      track[evt.paramName] = evt.value;
      
      // Update visual layout knob/fader
      updateControlVisuals(evt.paramName, track.id);
      
      // Send MIDI CC silently (does not trigger feedback recording loops)
      sendCCSilent(track, evt.paramName, evt.value);
    });
  });

  // Playback Microcosm automation
  if (state.microcosm.isPlaybackActive && state.microcosm.automationEvents.length > 0) {
    let mcEvents = [];
    if (!wrapped) {
      mcEvents = state.microcosm.automationEvents.filter(e => e.time >= lastTime && e.time < currentTime);
    } else {
      mcEvents = state.microcosm.automationEvents.filter(e => e.time >= lastTime && e.time <= transport.totalDurationMs)
                  .concat(state.microcosm.automationEvents.filter(e => e.time >= 0 && e.time < currentTime));
    }
    
    mcEvents.forEach(evt => {
      // Update state
      state.microcosm[evt.paramName] = evt.value;
      
      // Update visuals
      if (evt.paramName === 'bypass' || evt.paramName === 'preset') {
        updateMicrocosmNonKnobVisuals();
      } else {
        updateMicrocosmControlVisuals(evt.paramName);
      }
      
      // Send MIDI CC or PC
      if (evt.paramName === 'bypass') {
        const ccVal = evt.value ? 0 : 127;
        sendMicrocosmCC(MICROCOSM_CC.bypass, ccVal);
      } else if (evt.paramName === 'preset') {
        sendPC(state.microcosm.midiChannel, evt.value);
      } else {
        const cc = MICROCOSM_CC[evt.paramName];
        if (cc !== undefined) {
          sendMicrocosmCC(cc, evt.value);
        }
      }
    });
  }
}

// --- Web MIDI System ---
async function initMidi() {
  if (!navigator.requestMIDIAccess) {
    showNotification("Web MIDI is not supported by your browser. Use Chrome, Edge or Opera.", "error");
    updateMidiStatus(false, "Web MIDI Not Supported");
    return;
  }

  try {
    const access = await navigator.requestMIDIAccess();
    state.midiAccess = access;
    access.onstatechange = handleMidiStateChange;
    updateMidiDevices();
    showNotification("Web MIDI Initialized successfully");
  } catch (error) {
    console.error("MIDI Init Failed: ", error);
    showNotification("Could not access MIDI devices.", "error");
    updateMidiStatus(false, "MIDI Access Denied");
  }
}

function handleMidiStateChange(event) {
  updateMidiDevices();
  if (event.port.type === "output") {
    const action = event.port.state === "connected" ? "Connected" : "Disconnected";
    showNotification(`MIDI Device ${event.port.name} ${action}`);
  }
}

function updateMidiDevices() {
  if (!state.midiAccess) return;
  const outputs = Array.from(state.midiAccess.outputs.values());
  
  // Populate S4 selector
  el.midiDeviceSelect.innerHTML = '';
  // Populate Microcosm selector
  if (el.microcosmDeviceSelect) {
    el.microcosmDeviceSelect.innerHTML = '';
  }
  
  if (outputs.length === 0) {
    const opt = document.createElement('option');
    opt.value = "";
    opt.textContent = "No MIDI Outputs Found";
    el.midiDeviceSelect.appendChild(opt);
    
    if (el.microcosmDeviceSelect) {
      const optM = document.createElement('option');
      optM.value = "";
      optM.textContent = "No MIDI Outputs Found";
      el.microcosmDeviceSelect.appendChild(optM);
    }
    
    updateMidiStatus(false, "No MIDI Devices Available");
    state.midiOutput = null;
    state.microcosmOutput = null;
    return;
  }
  
  outputs.forEach(output => {
    // S4 options
    const opt = document.createElement('option');
    opt.value = output.id;
    opt.textContent = output.name || `Device ID: ${output.id}`;
    el.midiDeviceSelect.appendChild(opt);
    
    // Microcosm options
    if (el.microcosmDeviceSelect) {
      const optM = document.createElement('option');
      optM.value = output.id;
      optM.textContent = output.name || `Device ID: ${output.id}`;
      el.microcosmDeviceSelect.appendChild(optM);
    }
  });

  // Auto-route S4
  if (!state.midiOutput) {
    const s4Device = outputs.find(o => o.name && o.name.toLowerCase().includes('s4'));
    if (s4Device) {
      state.midiOutput = s4Device;
    } else {
      state.midiOutput = outputs[0];
    }
  }
  el.midiDeviceSelect.value = state.midiOutput ? state.midiOutput.id : "";

  // Auto-route Microcosm
  if (!state.microcosmOutput) {
    const mcDevice = outputs.find(o => o.name && (o.name.toLowerCase().includes('microcosm') || o.name.toLowerCase().includes('hologram')));
    if (mcDevice) {
      state.microcosmOutput = mcDevice;
    } else if (outputs.length > 1) {
      // Pick second device if available, otherwise fallback to first
      state.microcosmOutput = outputs[1];
    } else {
      state.microcosmOutput = outputs[0];
    }
  }
  if (el.microcosmDeviceSelect) {
    el.microcosmDeviceSelect.value = state.microcosmOutput ? state.microcosmOutput.id : "";
  }

  // Update Status Text
  let statusText = "";
  if (state.midiOutput && state.microcosmOutput) {
    statusText = `S4: ${state.midiOutput.name} | Microcosm: ${state.microcosmOutput.name}`;
  } else if (state.midiOutput) {
    statusText = `S4: ${state.midiOutput.name} | Microcosm: Disconnected`;
  } else if (state.microcosmOutput) {
    statusText = `S4: Disconnected | Microcosm: ${state.microcosmOutput.name}`;
  } else {
    statusText = "No MIDI Devices Connected";
  }
  updateMidiStatus(!!(state.midiOutput || state.microcosmOutput), statusText);
}

function updateMidiStatus(connected, text) {
  if (connected) {
    el.midiIndicator.className = "status-indicator connected";
  } else {
    el.midiIndicator.className = "status-indicator disconnected";
  }
  el.midiStatusText.textContent = text;
}

// --- Send MIDI CC ---
function sendCC(channel, ccNumber, value) {
  if (!state.midiOutput) return;
  const statusByte = 0xB0 | (channel - 1);
  try {
    state.midiOutput.send([statusByte, ccNumber, value]);
    
    // Trigger visual MIDI led flash on UI track
    const trackModule = document.querySelector(`.track-module[data-track="${channel}"]`);
    if (trackModule) {
      trackModule.classList.add('active-midi');
      setTimeout(() => trackModule.classList.remove('active-midi'), 80);
    }
  } catch (err) {
    console.error("Failed to send MIDI CC: ", err);
  }
}

// --- Send Microcosm MIDI CC ---
function sendMicrocosmCC(ccNumber, value) {
  if (!state.microcosmOutput) return;
  const channel = state.microcosm.midiChannel;
  try {
    if (channel === 'ALL') {
      for (let ch = 1; ch <= 16; ch++) {
        const statusByte = 0xB0 | (ch - 1);
        state.microcosmOutput.send([statusByte, ccNumber, value]);
      }
    } else {
      const statusByte = 0xB0 | (channel - 1);
      state.microcosmOutput.send([statusByte, ccNumber, value]);
    }
    
    // Visual flash of microcosm LED
    const led = document.querySelector('.microcosm-led');
    if (led) {
      led.style.background = '#00e5ff';
      led.style.boxShadow = '0 0 10px rgba(0, 229, 255, 0.8)';
      setTimeout(() => {
        if (!state.microcosm.bypass) {
          led.style.background = '#ff007f';
          led.style.boxShadow = '0 0 8px rgba(255, 0, 127, 0.6)';
        } else {
          led.style.background = '#331a24';
          led.style.boxShadow = 'none';
        }
      }, 80);
    }
  } catch (err) {
    console.error("Failed to send Microcosm CC: ", err);
  }
}

// --- Send Microcosm MIDI PC (Program Change) ---
function sendPC(channel, programNumber) {
  if (!state.microcosmOutput) return;
  const programByte = Math.max(0, Math.min(127, programNumber - 1)); // 1-60 -> 0-59
  try {
    if (channel === 'ALL') {
      for (let ch = 1; ch <= 16; ch++) {
        const statusByte = 0xC0 | (ch - 1);
        state.microcosmOutput.send([statusByte, programByte]);
      }
    } else {
      const statusByte = 0xC0 | (channel - 1);
      state.microcosmOutput.send([statusByte, programByte]);
    }
    
    const led = document.querySelector('.microcosm-led');
    if (led) {
      led.style.background = '#00e5ff';
      led.style.boxShadow = '0 0 10px rgba(0, 229, 255, 0.8)';
      setTimeout(() => {
        if (!state.microcosm.bypass) {
          led.style.background = '#ff007f';
          led.style.boxShadow = '0 0 8px rgba(255, 0, 127, 0.6)';
        } else {
          led.style.background = '#331a24';
          led.style.boxShadow = 'none';
        }
      }, 100);
    }
  } catch (err) {
    console.error("Failed to send MIDI PC: ", err);
  }
}

// Map parameters to their specific CC channels
function getCCNumber(paramName) {
  if (paramName === 'level') return MIDICC.LEVEL;
  if (paramName === 'cutoff') return MIDICC.CUTOFF;
  
  if (paramName.startsWith('send')) {
    const sNum = parseInt(paramName.replace('send', ''));
    return MIDICC.SENDS[sNum - 1];
  }
  
  if (paramName.startsWith('enc')) {
    const eNum = parseInt(paramName.replace('enc', ''));
    return MIDICC.ENCODERS[eNum - 1];
  }
  
  if (MIDICC.MATERIAL[paramName] !== undefined) {
    return MIDICC.MATERIAL[paramName];
  }
  
  if (paramName.startsWith('g')) {
    const key = paramName.substring(1).toLowerCase(); // 'gPitch' -> 'pitch'
    const matchKey = Object.keys(MIDICC.GRANULAR).find(k => k.toLowerCase() === key);
    if (matchKey) return MIDICC.GRANULAR[matchKey];
  }
  
  if (MIDICC.FILTER[paramName] !== undefined) {
    return MIDICC.FILTER[paramName];
  }
  if (paramName === 'fPitch') return MIDICC.FILTER.pitch;
  
  if (MIDICC.COLOUR[paramName] !== undefined) {
    return MIDICC.COLOUR[paramName];
  }
  
  if (MIDICC.SPACE[paramName] !== undefined) {
    return MIDICC.SPACE[paramName];
  }
  
  return null;
}

function sendCCSilent(track, paramName, value) {
  if (paramName === 'pan') {
    const panCCs = [54, 55, 56, 57];
    const cc = panCCs[track.id - 1];
    sendCC(16, cc, value); // Send Mixer Pan on MIDI Channel 16
  } else {
    const cc = getCCNumber(paramName);
    if (cc !== null) {
      sendCC(track.midiChannel, cc, value);
    }
  }
}

// --- UI Rendering ---
function renderTracks() {
  el.tracksGrid.innerHTML = '';
  
  state.tracks.forEach(track => {
    const trackHtml = `
      <div class="track-module" data-track="${track.id}">
        <!-- Module Header -->
        <div class="track-header">
          <div class="track-title-wrapper">
            <div class="track-led"></div>
            <div class="track-name">TRACK ${track.id}</div>
          </div>
          <div class="track-channel-badge">CH ${track.midiChannel}</div>
        </div>

        <!-- Mute & Solo buttons -->
        <div class="track-actions">
          <button class="btn-mute ${track.muted ? 'active' : ''}" data-track="${track.id}">MUTE</button>
          <button class="btn-solo ${track.soloed ? 'active' : ''}" data-track="${track.id}">SOLO</button>
        </div>

        <!-- Automation Controls -->
        <div class="track-automation-controls">
          <div class="automation-btns-wrapper">
            <button class="btn-rec" data-track="${track.id}" title="Record automation loop">● REC</button>
            <button class="btn-play-auto ${track.isPlaybackActive ? 'active' : ''}" data-track="${track.id}" title="Toggle automation playback">PLAY</button>
            <button class="btn-clr" data-track="${track.id}" title="Clear recorded automation">CLR</button>
          </div>
          <div class="automation-badge ${track.automationEvents.length > 0 ? 'has-events' : ''}" data-badge="${track.id}">
            ${track.automationEvents.length} evts
          </div>
        </div>

        <!-- Tab Selector Menu (S4 Signal Chain) -->
        <div class="track-tabs">
          <button class="tab-btn ${track.activeTab === 'mix' ? 'active' : ''}" data-tab="mix" data-track="${track.id}">MIX</button>
          <button class="tab-btn ${track.activeTab === 'material' ? 'active' : ''}" data-tab="material" data-track="${track.id}">MAT</button>
          <button class="tab-btn ${track.activeTab === 'granular' ? 'active' : ''}" data-tab="granular" data-track="${track.id}">GRA</button>
          <button class="tab-btn ${track.activeTab === 'filter' ? 'active' : ''}" data-tab="filter" data-track="${track.id}">FIL</button>
          <button class="tab-btn ${track.activeTab === 'colour' ? 'active' : ''}" data-tab="colour" data-track="${track.id}">COL</button>
          <button class="tab-btn ${track.activeTab === 'space' ? 'active' : ''}" data-tab="space" data-track="${track.id}">SPA</button>
        </div>

        <!-- TAB CONTENT: MIX (Volume, Cutoff, Sends) -->
        <div class="tab-content ${track.activeTab === 'mix' ? 'active' : ''}" data-tab-content="mix" data-track="${track.id}">
          <div class="strip-row">
            <!-- Level Fader -->
            <div class="fader-section">
              <span class="control-label">LEVEL</span>
              <div class="custom-fader" data-param="level" data-track="${track.id}">
                <div class="fader-track-highlight"></div>
                <div class="fader-handle"></div>
              </div>
              <div class="fader-value">${track.muted ? 0 : track.level}</div>
            </div>

            <!-- Filter Cutoff Knob (Shared CC 78) & Pan (Ch 16 CC 54-57) -->
            <div class="strip-right">
              <span class="cutoff-label">FILTER CUTOFF</span>
              <div class="knob-container knob-large" data-param="cutoff" data-track="${track.id}">
                <div class="knob-wrapper">
                  <svg class="knob-ring" viewBox="0 0 100 100">
                    <circle class="knob-ring-bg" cx="50" cy="50" r="40" stroke-width="6" fill="transparent" />
                    <circle class="knob-ring-fill" cx="50" cy="50" r="40" stroke-width="6" fill="transparent" style="stroke-dasharray: 188.5 251.3;" />
                  </svg>
                  <div class="knob">
                    <div class="knob-pointer"></div>
                  </div>
                </div>
                <div class="knob-value">${track.cutoff}</div>
              </div>

              <span class="cutoff-label">PAN</span>
              <div class="knob-container knob-medium" data-param="pan" data-track="${track.id}">
                <div class="knob-wrapper">
                  <svg class="knob-ring" viewBox="0 0 100 100">
                    <circle class="knob-ring-bg" cx="50" cy="50" r="40" stroke-width="6" fill="transparent" />
                    <circle class="knob-ring-fill" cx="50" cy="50" r="40" stroke-width="6" fill="transparent" style="stroke-dasharray: 188.5 251.3;" />
                  </svg>
                  <div class="knob">
                    <div class="knob-pointer"></div>
                  </div>
                </div>
                <div class="knob-value">${track.pan}</div>
              </div>
            </div>
          </div>

          <!-- Sends Section -->
          <div class="sends-section">
            <div class="section-title">SENDS (1 - 4)</div>
            <div class="sends-grid">
              ${[1, 2, 3, 4].map(sNum => `
                <div class="knob-container knob-small" data-param="send${sNum}" data-track="${track.id}">
                  <div class="knob-wrapper">
                    <svg class="knob-ring" viewBox="0 0 100 100">
                      <circle class="knob-ring-bg" cx="50" cy="50" r="40" stroke-width="6" fill="transparent" />
                      <circle class="knob-ring-fill" cx="50" cy="50" r="40" stroke-width="6" fill="transparent" style="stroke-dasharray: 188.5 251.3;" />
                    </svg>
                    <div class="knob">
                      <div class="knob-pointer"></div>
                    </div>
                  </div>
                  <div class="knob-label">S${sNum}</div>
                  <div class="knob-value">${track[`send${sNum}`]}</div>
                </div>
              `).join('')}
            </div>
          </div>
        </div>

        <!-- TAB CONTENT: MATERIAL (Playback Speed, Start, Length) -->
        <div class="tab-content ${track.activeTab === 'material' ? 'active' : ''}" data-tab-content="material" data-track="${track.id}">
          <div class="device-section-header">MATERIAL ENGINE (TAPE/SAMPLER)</div>
          <div class="material-grid">
            <!-- Speed -->
            <div class="knob-container knob-medium" data-param="speed" data-track="${track.id}">
              <div class="knob-wrapper">
                <svg class="knob-ring" viewBox="0 0 100 100">
                  <circle class="knob-ring-bg" cx="50" cy="50" r="40" stroke-width="6" fill="transparent" />
                  <circle class="knob-ring-fill" cx="50" cy="50" r="40" stroke-width="6" fill="transparent" style="stroke-dasharray: 188.5 251.3;" />
                </svg>
                <div class="knob">
                  <div class="knob-pointer"></div>
                </div>
              </div>
              <div class="knob-label">SPEED</div>
              <div class="knob-value">${track.speed}</div>
            </div>

            <!-- Start position -->
            <div class="knob-container knob-medium" data-param="start" data-track="${track.id}">
              <div class="knob-wrapper">
                <svg class="knob-ring" viewBox="0 0 100 100">
                  <circle class="knob-ring-bg" cx="50" cy="50" r="40" stroke-width="6" fill="transparent" />
                  <circle class="knob-ring-fill" cx="50" cy="50" r="40" stroke-width="6" fill="transparent" style="stroke-dasharray: 188.5 251.3;" />
                </svg>
                <div class="knob">
                  <div class="knob-pointer"></div>
                </div>
              </div>
              <div class="knob-label">START</div>
              <div class="knob-value">${track.start}</div>
            </div>

            <!-- Length -->
            <div class="knob-container knob-medium" data-param="length" data-track="${track.id}">
              <div class="knob-wrapper">
                <svg class="knob-ring" viewBox="0 0 100 100">
                  <circle class="knob-ring-bg" cx="50" cy="50" r="40" stroke-width="6" fill="transparent" />
                  <circle class="knob-ring-fill" cx="50" cy="50" r="40" stroke-width="6" fill="transparent" style="stroke-dasharray: 188.5 251.3;" />
                </svg>
                <div class="knob">
                  <div class="knob-pointer"></div>
                </div>
              </div>
              <div class="knob-label">LENGTH</div>
              <div class="knob-value">${track.length}</div>
            </div>
          </div>
        </div>

        <!-- TAB CONTENT: GRANULAR (Mosaic Device) -->
        <div class="tab-content ${track.activeTab === 'granular' ? 'active' : ''}" data-tab-content="granular" data-track="${track.id}">
          <div class="device-section-header">GRANULAR ENGINE (MOSAIC)</div>
          <div class="granular-grid">
            <!-- Pitch -->
            <div class="knob-container knob-medium" data-param="gPitch" data-track="${track.id}">
              <div class="knob-wrapper">
                <svg class="knob-ring" viewBox="0 0 100 100">
                  <circle class="knob-ring-bg" cx="50" cy="50" r="40" stroke-width="6" fill="transparent" />
                  <circle class="knob-ring-fill" cx="50" cy="50" r="40" stroke-width="6" fill="transparent" style="stroke-dasharray: 188.5 251.3;" />
                </svg>
                <div class="knob">
                  <div class="knob-pointer"></div>
                </div>
              </div>
              <div class="knob-label">PITCH</div>
              <div class="knob-value">${track.gPitch}</div>
            </div>

            <!-- Rate -->
            <div class="knob-container knob-medium" data-param="gRate" data-track="${track.id}">
              <div class="knob-wrapper">
                <svg class="knob-ring" viewBox="0 0 100 100">
                  <circle class="knob-ring-bg" cx="50" cy="50" r="40" stroke-width="6" fill="transparent" />
                  <circle class="knob-ring-fill" cx="50" cy="50" r="40" stroke-width="6" fill="transparent" style="stroke-dasharray: 188.5 251.3;" />
                </svg>
                <div class="knob">
                  <div class="knob-pointer"></div>
                </div>
              </div>
              <div class="knob-label">RATE</div>
              <div class="knob-value">${track.gRate}</div>
            </div>

            <!-- Size -->
            <div class="knob-container knob-medium" data-param="gSize" data-track="${track.id}">
              <div class="knob-wrapper">
                <svg class="knob-ring" viewBox="0 0 100 100">
                  <circle class="knob-ring-bg" cx="50" cy="50" r="40" stroke-width="6" fill="transparent" />
                  <circle class="knob-ring-fill" cx="50" cy="50" r="40" stroke-width="6" fill="transparent" style="stroke-dasharray: 188.5 251.3;" />
                </svg>
                <div class="knob">
                  <div class="knob-pointer"></div>
                </div>
              </div>
              <div class="knob-label">SIZE</div>
              <div class="knob-value">${track.gSize}</div>
            </div>

            <!-- Contour -->
            <div class="knob-container knob-medium" data-param="gContour" data-track="${track.id}">
              <div class="knob-wrapper">
                <svg class="knob-ring" viewBox="0 0 100 100">
                  <circle class="knob-ring-bg" cx="50" cy="50" r="40" stroke-width="6" fill="transparent" />
                  <circle class="knob-ring-fill" cx="50" cy="50" r="40" stroke-width="6" fill="transparent" style="stroke-dasharray: 188.5 251.3;" />
                </svg>
                <div class="knob">
                  <div class="knob-pointer"></div>
                </div>
              </div>
              <div class="knob-label">CONTOUR</div>
              <div class="knob-value">${track.gContour}</div>
            </div>

            <!-- Warp -->
            <div class="knob-container knob-medium" data-param="gWarp" data-track="${track.id}">
              <div class="knob-wrapper">
                <svg class="knob-ring" viewBox="0 0 100 100">
                  <circle class="knob-ring-bg" cx="50" cy="50" r="40" stroke-width="6" fill="transparent" />
                  <circle class="knob-ring-fill" cx="50" cy="50" r="40" stroke-width="6" fill="transparent" style="stroke-dasharray: 188.5 251.3;" />
                </svg>
                <div class="knob">
                  <div class="knob-pointer"></div>
                </div>
              </div>
              <div class="knob-label">WARP</div>
              <div class="knob-value">${track.gWarp}</div>
            </div>

            <!-- Spray -->
            <div class="knob-container knob-medium" data-param="gSpray" data-track="${track.id}">
              <div class="knob-wrapper">
                <svg class="knob-ring" viewBox="0 0 100 100">
                  <circle class="knob-ring-bg" cx="50" cy="50" r="40" stroke-width="6" fill="transparent" />
                  <circle class="knob-ring-fill" cx="50" cy="50" r="40" stroke-width="6" fill="transparent" style="stroke-dasharray: 188.5 251.3;" />
                </svg>
                <div class="knob">
                  <div class="knob-pointer"></div>
                </div>
              </div>
              <div class="knob-label">SPRAY</div>
              <div class="knob-value">${track.gSpray}</div>
            </div>
          </div>
        </div>

        <!-- TAB CONTENT: FILTER (Cutoff, Resonance, Decay, Mod Pitch, Slope) -->
        <div class="tab-content ${track.activeTab === 'filter' ? 'active' : ''}" data-tab-content="filter" data-track="${track.id}">
          <div class="device-section-header">FILTER ENGINE (MULTIMODE / RING)</div>
          <div class="filter-grid">
            <!-- Cutoff (Shared CC 78) -->
            <div class="knob-container knob-medium" data-param="cutoff" data-track="${track.id}">
              <div class="knob-wrapper">
                <svg class="knob-ring" viewBox="0 0 100 100">
                  <circle class="knob-ring-bg" cx="50" cy="50" r="40" stroke-width="6" fill="transparent" />
                  <circle class="knob-ring-fill" cx="50" cy="50" r="40" stroke-width="6" fill="transparent" style="stroke-dasharray: 188.5 251.3;" />
                </svg>
                <div class="knob">
                  <div class="knob-pointer"></div>
                </div>
              </div>
              <div class="knob-label">CUTOFF</div>
              <div class="knob-value">${track.cutoff}</div>
            </div>

            <!-- Resonance -->
            <div class="knob-container knob-medium" data-param="resonance" data-track="${track.id}">
              <div class="knob-wrapper">
                <svg class="knob-ring" viewBox="0 0 100 100">
                  <circle class="knob-ring-bg" cx="50" cy="50" r="40" stroke-width="6" fill="transparent" />
                  <circle class="knob-ring-fill" cx="50" cy="50" r="40" stroke-width="6" fill="transparent" style="stroke-dasharray: 188.5 251.3;" />
                </svg>
                <div class="knob">
                  <div class="knob-pointer"></div>
                </div>
              </div>
              <div class="knob-label">RES</div>
              <div class="knob-value">${track.resonance}</div>
            </div>

            <!-- Decay -->
            <div class="knob-container knob-medium" data-param="decay" data-track="${track.id}">
              <div class="knob-wrapper">
                <svg class="knob-ring" viewBox="0 0 100 100">
                  <circle class="knob-ring-bg" cx="50" cy="50" r="40" stroke-width="6" fill="transparent" />
                  <circle class="knob-ring-fill" cx="50" cy="50" r="40" stroke-width="6" fill="transparent" style="stroke-dasharray: 188.5 251.3;" />
                </svg>
                <div class="knob">
                  <div class="knob-pointer"></div>
                </div>
              </div>
              <div class="knob-label">DECAY</div>
              <div class="knob-value">${track.decay}</div>
            </div>

            <!-- Ring Mod Pitch -->
            <div class="knob-container knob-medium" data-param="fPitch" data-track="${track.id}">
              <div class="knob-wrapper">
                <svg class="knob-ring" viewBox="0 0 100 100">
                  <circle class="knob-ring-bg" cx="50" cy="50" r="40" stroke-width="6" fill="transparent" />
                  <circle class="knob-ring-fill" cx="50" cy="50" r="40" stroke-width="6" fill="transparent" style="stroke-dasharray: 188.5 251.3;" />
                </svg>
                <div class="knob">
                  <div class="knob-pointer"></div>
                </div>
              </div>
              <div class="knob-label">MOD PITCH</div>
              <div class="knob-value">${track.fPitch}</div>
            </div>

            <!-- Slope -->
            <div class="knob-container knob-medium" data-param="slope" data-track="${track.id}">
              <div class="knob-wrapper">
                <svg class="knob-ring" viewBox="0 0 100 100">
                  <circle class="knob-ring-bg" cx="50" cy="50" r="40" stroke-width="6" fill="transparent" />
                  <circle class="knob-ring-fill" cx="50" cy="50" r="40" stroke-width="6" fill="transparent" style="stroke-dasharray: 188.5 251.3;" />
                </svg>
                <div class="knob">
                  <div class="knob-pointer"></div>
                </div>
              </div>
              <div class="knob-label">SLOPE</div>
              <div class="knob-value">${track.slope}</div>
            </div>
          </div>
        </div>

        <!-- TAB CONTENT: COLOUR (Drive, Compress, Crush) -->
        <div class="tab-content ${track.activeTab === 'colour' ? 'active' : ''}" data-tab-content="colour" data-track="${track.id}">
          <div class="device-section-header">COLOUR ENGINE (DEFORM DRIVE)</div>
          <div class="colour-grid">
            <!-- Drive -->
            <div class="knob-container knob-medium" data-param="drive" data-track="${track.id}">
              <div class="knob-wrapper">
                <svg class="knob-ring" viewBox="0 0 100 100">
                  <circle class="knob-ring-bg" cx="50" cy="50" r="40" stroke-width="6" fill="transparent" />
                  <circle class="knob-ring-fill" cx="50" cy="50" r="40" stroke-width="6" fill="transparent" style="stroke-dasharray: 188.5 251.3;" />
                </svg>
                <div class="knob">
                  <div class="knob-pointer"></div>
                </div>
              </div>
              <div class="knob-label">DRIVE</div>
              <div class="knob-value">${track.drive}</div>
            </div>

            <!-- Compress -->
            <div class="knob-container knob-medium" data-param="compress" data-track="${track.id}">
              <div class="knob-wrapper">
                <svg class="knob-ring" viewBox="0 0 100 100">
                  <circle class="knob-ring-bg" cx="50" cy="50" r="40" stroke-width="6" fill="transparent" />
                  <circle class="knob-ring-fill" cx="50" cy="50" r="40" stroke-width="6" fill="transparent" style="stroke-dasharray: 188.5 251.3;" />
                </svg>
                <div class="knob">
                  <div class="knob-pointer"></div>
                </div>
              </div>
              <div class="knob-label">COMPRESS</div>
              <div class="knob-value">${track.compress}</div>
            </div>

            <!-- Crush -->
            <div class="knob-container knob-medium" data-param="crush" data-track="${track.id}">
              <div class="knob-wrapper">
                <svg class="knob-ring" viewBox="0 0 100 100">
                  <circle class="knob-ring-bg" cx="50" cy="50" r="40" stroke-width="6" fill="transparent" />
                  <circle class="knob-ring-fill" cx="50" cy="50" r="40" stroke-width="6" fill="transparent" style="stroke-dasharray: 188.5 251.3;" />
                </svg>
                <div class="knob">
                  <div class="knob-pointer"></div>
                </div>
              </div>
              <div class="knob-label">BIT CRUSH</div>
              <div class="knob-value">${track.crush}</div>
            </div>
          </div>
        </div>

        <!-- TAB CONTENT: SPACE (Delay Amt, Delay Time, Delay Feedback, Tone, Reverb Amt, Reverb Size, Reverb Decay, Spread) -->
        <div class="tab-content ${track.activeTab === 'space' ? 'active' : ''}" data-tab-content="space" data-track="${track.id}">
          <div class="fx-section-header">SPACE ENGINE (DELAY & REVERB)</div>
          
          <div class="space-fx-grid">
            <!-- Delay Amount -->
            <div class="knob-container knob-medium" data-param="delayAmt" data-track="${track.id}">
              <div class="knob-wrapper">
                <svg class="knob-ring" viewBox="0 0 100 100">
                  <circle class="knob-ring-bg" cx="50" cy="50" r="40" stroke-width="6" fill="transparent" />
                  <circle class="knob-ring-fill" cx="50" cy="50" r="40" stroke-width="6" fill="transparent" style="stroke-dasharray: 188.5 251.3;" />
                </svg>
                <div class="knob">
                  <div class="knob-pointer"></div>
                </div>
              </div>
              <div class="knob-label">D. AMT</div>
              <div class="knob-value">${track.delayAmt}</div>
            </div>

            <!-- Delay Time -->
            <div class="knob-container knob-medium" data-param="delayTime" data-track="${track.id}">
              <div class="knob-wrapper">
                <svg class="knob-ring" viewBox="0 0 100 100">
                  <circle class="knob-ring-bg" cx="50" cy="50" r="40" stroke-width="6" fill="transparent" />
                  <circle class="knob-ring-fill" cx="50" cy="50" r="40" stroke-width="6" fill="transparent" style="stroke-dasharray: 188.5 251.3;" />
                </svg>
                <div class="knob">
                  <div class="knob-pointer"></div>
                </div>
              </div>
              <div class="knob-label">D. TIME</div>
              <div class="knob-value">${track.delayTime}</div>
            </div>

            <!-- Delay Feedback -->
            <div class="knob-container knob-medium" data-param="delayFeedback" data-track="${track.id}">
              <div class="knob-wrapper">
                <svg class="knob-ring" viewBox="0 0 100 100">
                  <circle class="knob-ring-bg" cx="50" cy="50" r="40" stroke-width="6" fill="transparent" />
                  <circle class="knob-ring-fill" cx="50" cy="50" r="40" stroke-width="6" fill="transparent" style="stroke-dasharray: 188.5 251.3;" />
                </svg>
                <div class="knob">
                  <div class="knob-pointer"></div>
                </div>
              </div>
              <div class="knob-label">D. FEED</div>
              <div class="knob-value">${track.delayFeedback}</div>
            </div>

            <!-- Tone -->
            <div class="knob-container knob-medium" data-param="tone" data-track="${track.id}">
              <div class="knob-wrapper">
                <svg class="knob-ring" viewBox="0 0 100 100">
                  <circle class="knob-ring-bg" cx="50" cy="50" r="40" stroke-width="6" fill="transparent" />
                  <circle class="knob-ring-fill" cx="50" cy="50" r="40" stroke-width="6" fill="transparent" style="stroke-dasharray: 188.5 251.3;" />
                </svg>
                <div class="knob">
                  <div class="knob-pointer"></div>
                </div>
              </div>
              <div class="knob-label">TONE</div>
              <div class="knob-value">${track.tone}</div>
            </div>

            <!-- Reverb Amount -->
            <div class="knob-container knob-medium" data-param="reverbAmt" data-track="${track.id}">
              <div class="knob-wrapper">
                <svg class="knob-ring" viewBox="0 0 100 100">
                  <circle class="knob-ring-bg" cx="50" cy="50" r="40" stroke-width="6" fill="transparent" />
                  <circle class="knob-ring-fill" cx="50" cy="50" r="40" stroke-width="6" fill="transparent" style="stroke-dasharray: 188.5 251.3;" />
                </svg>
                <div class="knob">
                  <div class="knob-pointer"></div>
                </div>
              </div>
              <div class="knob-label">R. AMT</div>
              <div class="knob-value">${track.reverbAmt}</div>
            </div>

            <!-- Reverb Size -->
            <div class="knob-container knob-medium" data-param="reverbSize" data-track="${track.id}">
              <div class="knob-wrapper">
                <svg class="knob-ring" viewBox="0 0 100 100">
                  <circle class="knob-ring-bg" cx="50" cy="50" r="40" stroke-width="6" fill="transparent" />
                  <circle class="knob-ring-fill" cx="50" cy="50" r="40" stroke-width="6" fill="transparent" style="stroke-dasharray: 188.5 251.3;" />
                </svg>
                <div class="knob">
                  <div class="knob-pointer"></div>
                </div>
              </div>
              <div class="knob-label">R. SIZE</div>
              <div class="knob-value">${track.reverbSize}</div>
            </div>

            <!-- Reverb Decay -->
            <div class="knob-container knob-medium" data-param="reverbDecay" data-track="${track.id}">
              <div class="knob-wrapper">
                <svg class="knob-ring" viewBox="0 0 100 100">
                  <circle class="knob-ring-bg" cx="50" cy="50" r="40" stroke-width="6" fill="transparent" />
                  <circle class="knob-ring-fill" cx="50" cy="50" r="40" stroke-width="6" fill="transparent" style="stroke-dasharray: 188.5 251.3;" />
                </svg>
                <div class="knob">
                  <div class="knob-pointer"></div>
                </div>
              </div>
              <div class="knob-label">R. DECAY</div>
              <div class="knob-value">${track.reverbDecay}</div>
            </div>

            <!-- Spread -->
            <div class="knob-container knob-medium" data-param="spread" data-track="${track.id}">
              <div class="knob-wrapper">
                <svg class="knob-ring" viewBox="0 0 100 100">
                  <circle class="knob-ring-bg" cx="50" cy="50" r="40" stroke-width="6" fill="transparent" />
                  <circle class="knob-ring-fill" cx="50" cy="50" r="40" stroke-width="6" fill="transparent" style="stroke-dasharray: 188.5 251.3;" />
                </svg>
                <div class="knob">
                  <div class="knob-pointer"></div>
                </div>
              </div>
              <div class="knob-label">SPREAD</div>
              <div class="knob-value">${track.spread}</div>
            </div>
          </div>
        </div>
      </div>
    `;
    
    el.tracksGrid.insertAdjacentHTML('beforeend', trackHtml);
  });

  // Append Microcosm HTML
  const microcosmHtml = `
    <div class="microcosm-module">
      <!-- Module Header -->
      <div class="track-header">
        <div class="track-title-wrapper">
          <div class="track-led" style="background: #00e5ff; box-shadow: 0 0 8px rgba(0, 229, 255, 0.6);"></div>
          <div class="track-name microcosm-title">MICROCOSM</div>
        </div>
        <select id="microcosm-midi-channel" class="select-input" style="font-family: var(--font-mono); font-size: 0.65rem; color: #00e5ff; border-color: rgba(0, 229, 255, 0.2); background: rgba(0,0,0,0.4); padding: 2px 4px; height: auto; outline: none;">
          <option value="ALL" ${state.microcosm.midiChannel === 'ALL' ? 'selected' : ''}>CH ALL</option>
          ${Array.from({length: 16}, (_, i) => {
            const ch = i + 1;
            return `<option value="${ch}" ${state.microcosm.midiChannel === ch ? 'selected' : ''}>CH ${ch}</option>`;
          }).join('')}
        </select>
      </div>

      <!-- Bypass Control -->
      <div class="bypass-controls-wrapper">
        <button class="btn-bypass ${!state.microcosm.bypass ? 'active' : ''}" id="microcosm-bypass-btn">BYPASS</button>
        <div class="microcosm-led" style="${!state.microcosm.bypass ? 'background: #ff007f; box-shadow: 0 0 8px rgba(255, 0, 127, 0.6);' : ''}"></div>
      </div>

      <!-- Program Change Selector -->
      <div class="preset-pc-section">
        <label for="microcosm-pc-select" class="control-label" style="color: #00e5ff;">PRESET (PC)</label>
        <select id="microcosm-pc-select" class="select-input preset-pc-select">
          ${Array.from({length: 60}, (_, i) => {
            const pNum = i + 1;
            return `<option value="${pNum}" ${state.microcosm.preset === pNum ? 'selected' : ''}>Preset ${pNum}</option>`;
          }).join('')}
        </select>
      </div>

      <!-- Automation Controls -->
      <div class="track-automation-controls" style="border-color: rgba(0, 229, 255, 0.05);">
        <div class="automation-btns-wrapper">
          <button class="btn-rec" id="microcosm-rec-btn" title="Record microcosm automation">● REC</button>
          <button class="btn-play-auto ${state.microcosm.isPlaybackActive ? 'active' : ''}" id="microcosm-play-btn" title="Toggle microcosm automation playback">PLAY</button>
          <button class="btn-clr" id="microcosm-clr-btn" title="Clear microcosm automation">CLR</button>
        </div>
        <div class="automation-badge ${state.microcosm.automationEvents.length > 0 ? 'has-events' : ''}" id="microcosm-auto-badge">
          ${state.microcosm.automationEvents.length} evts
        </div>
      </div>

      <!-- Microcosm Parameters Grid -->
      <div class="microcosm-grid">
        ${[
          { id: 'activity', label: 'ACTIVITY' },
          { id: 'shape', label: 'SHAPE' },
          { id: 'filter', label: 'FILTER' },
          { id: 'mix', label: 'MIX' },
          { id: 'time', label: 'TIME' },
          { id: 'repeats', label: 'REPEATS' },
          { id: 'space', label: 'SPACE' },
          { id: 'loopLevel', label: 'LOOP LVL' },
          { id: 'modRate', label: 'MOD RATE' },
          { id: 'modDepth', label: 'MOD DEPTH' },
          { id: 'reverbTime', label: 'REV TIME' }
        ].map(param => `
          <div class="knob-container knob-medium" data-device="microcosm" data-param="${param.id}">
            <div class="knob-wrapper">
              <svg class="knob-ring" viewBox="0 0 100 100">
                <circle class="knob-ring-bg" cx="50" cy="50" r="40" stroke-width="6" fill="transparent" />
                <circle class="knob-ring-fill" cx="50" cy="50" r="40" stroke-width="6" fill="transparent" style="stroke-dasharray: 188.5 251.3;" />
              </svg>
              <div class="knob">
                <div class="knob-pointer"></div>
              </div>
            </div>
            <div class="knob-label">${param.label}</div>
            <div class="knob-value">${state.microcosm[param.id]}</div>
          </div>
        `).join('')}
      </div>
    </div>
  `;
  el.tracksGrid.insertAdjacentHTML('beforeend', microcosmHtml);

  // Attach control drag/mouse behaviors after DOM elements are created
  attachControlListeners();
}

function updateControlVisuals(paramName, trackId) {
  const track = state.tracks.find(t => t.id === trackId);
  if (!track) return;

  const value = track[paramName];
  const percentage = value / 127;

  // Find DOM container
  const container = document.querySelector(`.track-module[data-track="${trackId}"] [data-param="${paramName}"]`);
  if (!container) return;

  if (paramName === 'level') {
    // Update Fader
    const handle = container.querySelector('.fader-handle');
    const highlight = container.querySelector('.fader-track-highlight');
    const valText = container.parentNode.querySelector('.fader-value');
    
    const displayVal = track.muted ? 0 : value;
    handle.style.bottom = `calc(${percentage * 100}% - 11px)`;
    highlight.style.height = `${percentage * 100}%`;
    valText.textContent = displayVal;
  } else {
    // Update Knob
    const knob = container.querySelector('.knob');
    const ringFill = container.querySelector('.knob-ring-fill');
    const valText = container.querySelector('.knob-value');
    
    // Rotate knob: -135deg (value 0) to 135deg (value 127)
    const angle = -135 + percentage * 270;
    knob.style.transform = `rotate(${angle}deg)`;
    
    // SVG circular fill arc
    const fillCircumference = 2 * Math.PI * 40; // R=40 => 251.32
    const maxArc = fillCircumference * 0.75; // 188.5 active arc
    const dashoffset = maxArc * (1 - percentage);
    ringFill.style.strokeDashoffset = dashoffset;
    
    if (valText) valText.textContent = value;
  }
}

function updateAllVisuals() {
  state.tracks.forEach(track => {
    Object.keys(DEFAULT_TRACK_PARAMS()).forEach(param => {
      if (param !== 'activeTab' && param !== 'isRecording' && param !== 'isPlaybackActive' && param !== 'automationEvents') {
        updateControlVisuals(param, track.id);
      }
    });
    
    // Update mute/solo classes
    const trackModule = document.querySelector(`.track-module[data-track="${track.id}"]`);
    if (trackModule) {
      const muteBtn = trackModule.querySelector('.btn-mute');
      const soloBtn = trackModule.querySelector('.btn-solo');
      const recBtn = trackModule.querySelector('.btn-rec');
      const playAutoBtn = trackModule.querySelector('.btn-play-auto');
      
      if (track.muted) muteBtn.classList.add('active');
      else muteBtn.classList.remove('active');
      
      if (track.soloed) soloBtn.classList.add('active');
      else soloBtn.classList.remove('active');

      if (track.isRecording) recBtn.classList.add('active');
      else recBtn.classList.remove('active');

      if (track.isPlaybackActive) playAutoBtn.classList.add('active');
      else playAutoBtn.classList.remove('active');
      
      // Update Tab button active states
      trackModule.querySelectorAll('.tab-btn').forEach(btn => {
        const tab = btn.getAttribute('data-tab');
        if (tab === track.activeTab) btn.classList.add('active');
        else btn.classList.remove('active');
      });

      // Show/Hide Tab content divs
      trackModule.querySelectorAll('.tab-content').forEach(content => {
        const tab = content.getAttribute('data-tab-content');
        if (tab === track.activeTab) content.classList.add('active');
        else content.classList.remove('active');
      });
      
      // Update event badge count
      updateAutomationBadge(track.id);
    }
  });

  // Update Microcosm visuals
  Object.keys(MICROCOSM_CC).forEach(param => {
    if (param !== 'bypass') {
      updateMicrocosmControlVisuals(param);
    }
  });
  updateMicrocosmNonKnobVisuals();
}

function updateMicrocosmControlVisuals(paramName) {
  const value = state.microcosm[paramName];
  const percentage = value / 127;
  
  const container = document.querySelector(`.microcosm-module [data-param="${paramName}"][data-device="microcosm"]`);
  if (!container) return;
  
  const knob = container.querySelector('.knob');
  const ringFill = container.querySelector('.knob-ring-fill');
  const valText = container.querySelector('.knob-value');
  
  const angle = -135 + percentage * 270;
  if (knob) knob.style.transform = `rotate(${angle}deg)`;
  
  const fillCircumference = 2 * Math.PI * 40;
  const maxArc = fillCircumference * 0.75;
  const dashoffset = maxArc * (1 - percentage);
  if (ringFill) ringFill.style.strokeDashoffset = dashoffset;
  
  if (valText) valText.textContent = value;
}

function updateMicrocosmNonKnobVisuals() {
  const bypassBtn = document.getElementById('microcosm-bypass-btn');
  const led = document.querySelector('.microcosm-led');
  const pcSelect = document.getElementById('microcosm-pc-select');
  const recBtn = document.getElementById('microcosm-rec-btn');
  const playBtn = document.getElementById('microcosm-play-btn');
  const badge = document.getElementById('microcosm-auto-badge');
  
  if (bypassBtn) {
    if (!state.microcosm.bypass) {
      bypassBtn.classList.add('active');
    } else {
      bypassBtn.classList.remove('active');
    }
  }
  
  if (led) {
    if (!state.microcosm.bypass) {
      led.style.background = '#ff007f';
      led.style.boxShadow = '0 0 8px rgba(255, 0, 127, 0.6)';
    } else {
      led.style.background = '#331a24';
      led.style.boxShadow = 'none';
    }
  }
  
  if (pcSelect) {
    pcSelect.value = state.microcosm.preset;
  }
  
  if (recBtn) {
    if (state.microcosm.isRecording) {
      recBtn.classList.add('active');
    } else {
      recBtn.classList.remove('active');
    }
  }
  
  if (playBtn) {
    if (state.microcosm.isPlaybackActive) {
      playBtn.classList.add('active');
    } else {
      playBtn.classList.remove('active');
    }
  }
  
  if (badge) {
    const count = state.microcosm.automationEvents.length;
    badge.textContent = `${count} evts`;
    if (count > 0) {
      badge.classList.add('has-events');
    } else {
      badge.classList.remove('has-events');
    }
  }

  const chanSelect = document.getElementById('microcosm-midi-channel');
  if (chanSelect) {
    chanSelect.value = state.microcosm.midiChannel;
  }
}

function updateAutomationBadge(trackId) {
  const track = state.tracks.find(t => t.id === trackId);
  const badge = document.querySelector(`[data-badge="${trackId}"]`);
  if (track && badge) {
    const count = track.automationEvents.length;
    badge.textContent = `${count} evts`;
    if (count > 0) {
      badge.classList.add('has-events');
    } else {
      badge.classList.remove('has-events');
    }
  }
}

// --- Interaction Logic ---
function attachControlListeners() {
  const S4controls = document.querySelectorAll('.track-module [data-param]');
  
  S4controls.forEach(ctrl => {
    if (ctrl.getAttribute('data-device') === 'microcosm') return;
    const trackId = parseInt(ctrl.getAttribute('data-track'));
    const paramName = ctrl.getAttribute('data-param');
    const isFader = ctrl.classList.contains('custom-fader');
    
    updateControlVisuals(paramName, trackId);

    ctrl.addEventListener('mousedown', (e) => {
      e.preventDefault();
      startDrag(e.clientY, trackId, paramName, isFader, ctrl);
    });

    ctrl.addEventListener('touchstart', (e) => {
      e.preventDefault();
      const touch = e.touches[0];
      startDrag(touch.clientY, trackId, paramName, isFader, ctrl);
    });

    ctrl.addEventListener('dblclick', () => {
      resetParamToDefault(trackId, paramName);
    });
  });

  // Attach Microcosm Knobs listeners
  const microcosmControls = document.querySelectorAll('[data-device="microcosm"]');
  microcosmControls.forEach(ctrl => {
    const paramName = ctrl.getAttribute('data-param');
    updateMicrocosmControlVisuals(paramName);
    
    ctrl.addEventListener('mousedown', (e) => {
      e.preventDefault();
      startMicrocosmDrag(e.clientY, paramName, ctrl);
    });

    ctrl.addEventListener('touchstart', (e) => {
      e.preventDefault();
      const touch = e.touches[0];
      startMicrocosmDrag(touch.clientY, paramName, ctrl);
    });

    ctrl.addEventListener('dblclick', () => {
      resetMicrocosmParamToDefault(paramName);
    });
  });

  // Setup Mute/Solo button clicks
  document.querySelectorAll('.btn-mute').forEach(btn => {
    btn.addEventListener('click', () => {
      const trackId = parseInt(btn.getAttribute('data-track'));
      toggleMute(trackId);
    });
  });

  document.querySelectorAll('.btn-solo').forEach(btn => {
    btn.addEventListener('click', () => {
      const trackId = parseInt(btn.getAttribute('data-track'));
      toggleSolo(trackId);
    });
  });

  // Setup Tab Button clicks
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const trackId = parseInt(btn.getAttribute('data-track'));
      const targetTab = btn.getAttribute('data-tab');
      switchTab(trackId, targetTab);
    });
  });

  // Setup Automation Buttons (S4)
  document.querySelectorAll('.track-module:not(.microcosm-module) .btn-rec').forEach(btn => {
    btn.addEventListener('click', () => {
      const trackId = parseInt(btn.getAttribute('data-track'));
      toggleTrackRecord(trackId);
    });
  });

  document.querySelectorAll('.track-module:not(.microcosm-module) .btn-play-auto').forEach(btn => {
    btn.addEventListener('click', () => {
      const trackId = parseInt(btn.getAttribute('data-track'));
      toggleTrackAutomationPlayback(trackId);
    });
  });

  document.querySelectorAll('.track-module:not(.microcosm-module) .btn-clr').forEach(btn => {
    btn.addEventListener('click', () => {
      const trackId = parseInt(btn.getAttribute('data-track'));
      clearTrackAutomation(trackId);
    });
  });

  // Microcosm Non-knob controls
  const mcBypassBtn = document.getElementById('microcosm-bypass-btn');
  if (mcBypassBtn) {
    mcBypassBtn.addEventListener('click', () => {
      toggleMicrocosmBypass();
    });
  }
  
  const mcPcSelect = document.getElementById('microcosm-pc-select');
  if (mcPcSelect) {
    mcPcSelect.addEventListener('change', () => {
      changeMicrocosmPreset(parseInt(mcPcSelect.value));
    });
  }
  
  const mcRecBtn = document.getElementById('microcosm-rec-btn');
  if (mcRecBtn) {
    mcRecBtn.addEventListener('click', () => {
      toggleMicrocosmRecord();
    });
  }
  
  const mcPlayBtn = document.getElementById('microcosm-play-btn');
  if (mcPlayBtn) {
    mcPlayBtn.addEventListener('click', () => {
      toggleMicrocosmPlayback();
    });
  }
  
  const mcClrBtn = document.getElementById('microcosm-clr-btn');
  if (mcClrBtn) {
    mcClrBtn.addEventListener('click', () => {
      clearMicrocosmAutomation();
    });
  }

  const mcChanSelect = document.getElementById('microcosm-midi-channel');
  if (mcChanSelect) {
    mcChanSelect.addEventListener('change', () => {
      const val = mcChanSelect.value;
      state.microcosm.midiChannel = val === 'ALL' ? 'ALL' : parseInt(val);
      showNotification(`Microcosm MIDI Channel set to: ${state.microcosm.midiChannel}`);
      transmitMicrocosmAll();
    });
  }
}

function switchTab(trackId, tabName) {
  const track = state.tracks.find(t => t.id === trackId);
  if (!track) return;
  
  track.activeTab = tabName;
  
  const trackModule = document.querySelector(`.track-module[data-track="${trackId}"]`);
  if (trackModule) {
    trackModule.querySelectorAll('.tab-btn').forEach(btn => {
      if (btn.getAttribute('data-tab') === tabName) btn.classList.add('active');
      else btn.classList.remove('active');
    });

    trackModule.querySelectorAll('.tab-content').forEach(content => {
      if (content.getAttribute('data-tab-content') === tabName) content.classList.add('active');
      else content.classList.remove('active');
    });
  }
}

function startDrag(startY, trackId, paramName, isFader, controlEl) {
  controlEl.classList.add('active');
  const track = state.tracks.find(t => t.id === trackId);
  const startVal = track[paramName];
  
  const dragRange = isFader ? 160 : 100; 
  const sensitivity = 127 / dragRange;

  const onMouseMove = (moveEvent) => {
    const currentY = moveEvent.clientY !== undefined ? moveEvent.clientY : moveEvent.touches[0].clientY;
    const deltaY = startY - currentY;
    
    let newVal = Math.round(startVal + deltaY * sensitivity);
    newVal = Math.max(0, Math.min(127, newVal));
    
    updateParamValue(trackId, paramName, newVal);
  };

  const onMouseUp = () => {
    controlEl.classList.remove('active');
    window.removeEventListener('mousemove', onMouseMove);
    window.removeEventListener('mouseup', onMouseUp);
    window.removeEventListener('touchmove', onMouseMove);
    window.removeEventListener('touchend', onMouseUp);
  };

  window.addEventListener('mousemove', onMouseMove);
  window.addEventListener('mouseup', onMouseUp);
  window.addEventListener('touchmove', onMouseMove, { passive: false });
  window.addEventListener('touchend', onMouseUp);
}

function updateParamValue(trackId, paramName, value) {
  const track = state.tracks.find(t => t.id === trackId);
  if (!track) return;

  track[paramName] = value;
  updateControlVisuals(paramName, trackId);

  // If recording and global transport is playing, log automation event
  if (track.isRecording && transport.isPlaying) {
    // Record relative to current playhead
    track.automationEvents.push({
      time: transport.playheadMs,
      paramName: paramName,
      value: value
    });
    
    // Sort events by timestamp
    track.automationEvents.sort((a, b) => a.time - b.time);
    
    // Update track event count display
    updateAutomationBadge(trackId);
  }

  // Send MIDI CC immediately
  if (paramName === 'pan') {
    const panCCs = [54, 55, 56, 57];
    const cc = panCCs[trackId - 1];
    sendCC(16, cc, value); // Send mixer pan to MIDI Channel 16
  } else if (paramName === 'level') {
    if (!track.muted) {
      sendCC(track.midiChannel, MIDICC.LEVEL, value);
    }
  } else {
    sendCCSilent(track, paramName, value);
  }
}

function resetParamToDefault(trackId, paramName) {
  let defaultVal = 64;
  if (paramName === 'level') defaultVal = 100;
  if (paramName.startsWith('send')) defaultVal = 0;
  if (paramName === 'delayAmt' || paramName === 'reverbAmt') defaultVal = 0;
  if (paramName === 'gWarp' || paramName === 'gSpray' || paramName === 'drive' || paramName === 'compress' || paramName === 'crush' || paramName === 'resonance' || paramName === 'slope') defaultVal = 0;
  if (paramName === 'length') defaultVal = 127;
  
  updateParamValue(trackId, paramName, defaultVal);
}

// --- Track Automation Logic ---
function toggleTrackRecord(trackId) {
  const track = state.tracks.find(t => t.id === trackId);
  if (!track) return;
  
  track.isRecording = !track.isRecording;
  const recBtn = document.querySelector(`.btn-rec[data-track="${trackId}"]`);
  
  if (track.isRecording) {
    recBtn.classList.add('active');
    // Start global transport automatically if stopped
    if (!transport.isPlaying) {
      toggleTransport();
    }
  } else {
    recBtn.classList.remove('active');
  }
}

function toggleTrackAutomationPlayback(trackId) {
  const track = state.tracks.find(t => t.id === trackId);
  if (!track) return;
  
  track.isPlaybackActive = !track.isPlaybackActive;
  const playAutoBtn = document.querySelector(`.btn-play-auto[data-track="${trackId}"]`);
  
  if (track.isPlaybackActive) {
    playAutoBtn.classList.add('active');
  } else {
    playAutoBtn.classList.remove('active');
  }
}

function clearTrackAutomation(trackId) {
  const track = state.tracks.find(t => t.id === trackId);
  if (!track) return;
  
  track.automationEvents = [];
  updateAutomationBadge(trackId);
  showNotification(`Cleared automation loop for Track ${trackId}`);
}

// --- Microcosm Control & Automation Logic ---
function startMicrocosmDrag(startY, paramName, controlEl) {
  controlEl.classList.add('active');
  const startVal = state.microcosm[paramName];
  
  const dragRange = 100;
  const sensitivity = 127 / dragRange;

  const onMouseMove = (moveEvent) => {
    const currentY = moveEvent.clientY !== undefined ? moveEvent.clientY : moveEvent.touches[0].clientY;
    const deltaY = startY - currentY;
    
    let newVal = Math.round(startVal + deltaY * sensitivity);
    newVal = Math.max(0, Math.min(127, newVal));
    
    updateMicrocosmParamValue(paramName, newVal);
  };

  const onMouseUp = () => {
    controlEl.classList.remove('active');
    window.removeEventListener('mousemove', onMouseMove);
    window.removeEventListener('mouseup', onMouseUp);
    window.removeEventListener('touchmove', onMouseMove);
    window.removeEventListener('touchend', onMouseUp);
  };

  window.addEventListener('mousemove', onMouseMove);
  window.addEventListener('mouseup', onMouseUp);
  window.addEventListener('touchmove', onMouseMove, { passive: false });
  window.addEventListener('touchend', onMouseUp);
}

function updateMicrocosmParamValue(paramName, value) {
  state.microcosm[paramName] = value;
  updateMicrocosmControlVisuals(paramName);

  // If recording and global transport is playing, log microcosm automation event
  if (state.microcosm.isRecording && transport.isPlaying) {
    state.microcosm.automationEvents.push({
      time: transport.playheadMs,
      paramName: paramName,
      value: value
    });
    
    // Sort events by timestamp
    state.microcosm.automationEvents.sort((a, b) => a.time - b.time);
    
    // Update microcosm event count display
    updateMicrocosmNonKnobVisuals();
  }

  // Send MIDI CC immediately
  const cc = MICROCOSM_CC[paramName];
  if (cc !== undefined) {
    sendMicrocosmCC(cc, value);
  }
}

function resetMicrocosmParamToDefault(paramName) {
  let defaultVal = 64;
  if (paramName === 'activity' || paramName === 'space' || paramName === 'modRate' || paramName === 'modDepth') {
    defaultVal = 0;
  }
  updateMicrocosmParamValue(paramName, defaultVal);
}

function toggleMicrocosmBypass() {
  state.microcosm.bypass = !state.microcosm.bypass;
  updateMicrocosmNonKnobVisuals();
  
  // Send CC 102: false (engaged) -> 127, true (bypass) -> 0
  const value = state.microcosm.bypass ? 0 : 127;
  sendMicrocosmCC(MICROCOSM_CC.bypass, value);
  
  // If recording and global transport is playing, log bypass automation event
  if (state.microcosm.isRecording && transport.isPlaying) {
    state.microcosm.automationEvents.push({
      time: transport.playheadMs,
      paramName: 'bypass',
      value: state.microcosm.bypass
    });
    state.microcosm.automationEvents.sort((a, b) => a.time - b.time);
    updateMicrocosmNonKnobVisuals();
  }
}

function changeMicrocosmPreset(pcValue) {
  state.microcosm.preset = pcValue;
  updateMicrocosmNonKnobVisuals();
  sendPC(state.microcosm.midiChannel, pcValue);
  
  // If recording and global transport is playing, log preset program change event
  if (state.microcosm.isRecording && transport.isPlaying) {
    state.microcosm.automationEvents.push({
      time: transport.playheadMs,
      paramName: 'preset',
      value: pcValue
    });
    state.microcosm.automationEvents.sort((a, b) => a.time - b.time);
    updateMicrocosmNonKnobVisuals();
  }
}

function toggleMicrocosmRecord() {
  state.microcosm.isRecording = !state.microcosm.isRecording;
  updateMicrocosmNonKnobVisuals();
  
  if (state.microcosm.isRecording && !transport.isPlaying) {
    toggleTransport();
  }
}

function toggleMicrocosmPlayback() {
  state.microcosm.isPlaybackActive = !state.microcosm.isPlaybackActive;
  updateMicrocosmNonKnobVisuals();
}

function clearMicrocosmAutomation() {
  state.microcosm.automationEvents = [];
  updateMicrocosmNonKnobVisuals();
  showNotification("Cleared Microcosm automation loop");
}

// --- Mute / Solo Logic ---
function toggleMute(trackId) {
  const track = state.tracks.find(t => t.id === trackId);
  if (!track) return;

  track.muted = !track.muted;
  
  const midiVal = track.muted ? 0 : track.level;
  sendCC(track.midiChannel, MIDICC.LEVEL, midiVal);
  
  updateControlVisuals('level', trackId);
  
  const muteBtn = document.querySelector(`.btn-mute[data-track="${trackId}"]`);
  if (track.muted) muteBtn.classList.add('active');
  else muteBtn.classList.remove('active');
}

function toggleSolo(trackId) {
  const targetTrack = state.tracks.find(t => t.id === trackId);
  if (!targetTrack) return;

  targetTrack.soloed = !targetTrack.soloed;
  const anySoloed = state.tracks.some(t => t.soloed);

  state.tracks.forEach(track => {
    if (anySoloed) {
      track.muted = !track.soloed;
    } else {
      track.muted = false;
    }
    const midiVal = track.muted ? 0 : track.level;
    sendCC(track.midiChannel, MIDICC.LEVEL, midiVal);
  });

  updateAllVisuals();
}

// --- Preset Management System ---
function loadLocalPresets() {
  const localData = localStorage.getItem('s4_ctrl_presets_v2');
  if (localData) {
    try {
      state.presets = JSON.parse(localData);
    } catch (e) {
      console.error("Failed to parse local presets: ", e);
      state.presets = [];
    }
  }
  updatePresetDropdown();
}

function saveLocalPresets() {
  localStorage.setItem('s4_ctrl_presets_v2', JSON.stringify(state.presets));
}

// Cleans preset loading data to support backwards/forwards compatibility
function cleanPresetState(tracksData) {
  return tracksData.map(track => {
    const defaults = DEFAULT_TRACK_PARAMS();
    return Object.assign({}, defaults, track);
  });
}

function updatePresetDropdown() {
  el.presetSelect.innerHTML = '<option value="">Default Init State</option>';
  
  state.presets.forEach((preset, index) => {
    const opt = document.createElement('option');
    opt.value = index;
    opt.textContent = preset.name;
    el.presetSelect.appendChild(opt);
  });

  if (state.activePresetIndex >= 0) {
    el.presetSelect.value = state.activePresetIndex;
    el.newPresetName.value = state.presets[state.activePresetIndex].name;
  } else {
    el.presetSelect.value = "";
    el.newPresetName.value = "";
  }
}

function loadPreset(index) {
  state.activePresetIndex = index;
  
  const defaultMC = () => ({
    activity: 0,
    shape: 0,
    filter: 64,
    mix: 64,
    time: 64,
    repeats: 64,
    space: 0,
    loopLevel: 64,
    modRate: 0,
    modDepth: 0,
    reverbTime: 64,
    bypass: false,
    preset: 1,
    isRecording: false,
    isPlaybackActive: true,
    automationEvents: []
  });

  if (index === -1) {
    // Reset to default init parameters
    state.tracks.forEach(track => {
      const defaults = DEFAULT_TRACK_PARAMS();
      Object.assign(track, defaults);
    });
    
    Object.assign(state.microcosm, defaultMC());
    
    transport.bpm = 120;
    transport.loopBars = 16;
    el.globalBpm.value = 120;
    el.globalBpmVal.textContent = "120";
    el.globalLoopBars.value = "16";
    updateLoopDuration();
    
    showNotification("Initialized default parameters");
  } else {
    const preset = state.presets[index];
    
    // Load global transport settings if stored in preset
    if (preset.bpm) {
      transport.bpm = preset.bpm;
      el.globalBpm.value = preset.bpm;
      el.globalBpmVal.textContent = preset.bpm;
    }
    if (preset.loopBars) {
      transport.loopBars = preset.loopBars;
      el.globalLoopBars.value = preset.loopBars;
    }
    updateLoopDuration();
    
    // Load track states
    const cleanTracks = cleanPresetState(preset.tracks);
    state.tracks.forEach((track, i) => {
      if (cleanTracks[i]) {
        Object.assign(track, cleanTracks[i]);
      }
    });

    // Load Microcosm state
    if (preset.microcosm) {
      Object.assign(state.microcosm, defaultMC(), preset.microcosm);
    } else {
      Object.assign(state.microcosm, defaultMC());
    }

    showNotification(`Loaded Preset: ${preset.name}`);
  }

  // Update UI components
  updateAllVisuals();

  // Transmit values to S4 & Microcosm
  transmitAllParameters();
  transmitMicrocosmAll();
  updatePresetDropdown();
}

function transmitAllParameters() {
  if (!state.midiOutput) return;

  state.tracks.forEach(track => {
    // Transmit fader
    const levelVal = track.muted ? 0 : track.level;
    sendCC(track.midiChannel, MIDICC.LEVEL, levelVal);
    
    // Transmit all active CC channels
    sendCCSilent(track, 'cutoff', track.cutoff);
    sendCCSilent(track, 'pan', track.pan);
    sendCCSilent(track, 'send1', track.send1);
    sendCCSilent(track, 'send2', track.send2);
    sendCCSilent(track, 'send3', track.send3);
    sendCCSilent(track, 'send4', track.send4);
    
    sendCCSilent(track, 'speed', track.speed);
    sendCCSilent(track, 'start', track.start);
    sendCCSilent(track, 'length', track.length);
    
    sendCCSilent(track, 'gPitch', track.gPitch);
    sendCCSilent(track, 'gRate', track.gRate);
    sendCCSilent(track, 'gSize', track.gSize);
    sendCCSilent(track, 'gContour', track.gContour);
    sendCCSilent(track, 'gWarp', track.gWarp);
    sendCCSilent(track, 'gSpray', track.gSpray);
    
    sendCCSilent(track, 'resonance', track.resonance);
    sendCCSilent(track, 'decay', track.decay);
    sendCCSilent(track, 'fPitch', track.fPitch);
    sendCCSilent(track, 'slope', track.slope);
    
    sendCCSilent(track, 'drive', track.drive);
    sendCCSilent(track, 'compress', track.compress);
    sendCCSilent(track, 'crush', track.crush);
    
    sendCCSilent(track, 'delayAmt', track.delayAmt);
    sendCCSilent(track, 'delayTime', track.delayTime);
    sendCCSilent(track, 'delayFeedback', track.delayFeedback);
    sendCCSilent(track, 'tone', track.tone);
    sendCCSilent(track, 'reverbAmt', track.reverbAmt);
    sendCCSilent(track, 'reverbSize', track.reverbSize);
    sendCCSilent(track, 'reverbDecay', track.reverbDecay);
    sendCCSilent(track, 'spread', track.spread);
  });
}

function transmitMicrocosmAll() {
  if (!state.microcosmOutput) return;

  // Transmit all knobs
  Object.keys(MICROCOSM_CC).forEach(param => {
    if (param !== 'bypass') {
      sendMicrocosmCC(MICROCOSM_CC[param], state.microcosm[param]);
    }
  });

  // Transmit bypass
  const bypassVal = state.microcosm.bypass ? 0 : 127;
  sendMicrocosmCC(MICROCOSM_CC.bypass, bypassVal);

  // Transmit preset Program Change
  sendPC(state.microcosm.midiChannel, state.microcosm.preset);
}

function savePreset() {
  const name = el.newPresetName.value.trim();
  if (!name) {
    showNotification("Please enter a Preset Name", "error");
    return;
  }

  const newPresetData = {
    name: name,
    bpm: transport.bpm,
    loopBars: transport.loopBars,
    tracks: state.tracks.map(t => ({
      level: t.level,
      cutoff: t.cutoff,
      pan: t.pan,
      send1: t.send1,
      send2: t.send2,
      send3: t.send3,
      send4: t.send4,
      speed: t.speed,
      start: t.start,
      length: t.length,
      gPitch: t.gPitch,
      gRate: t.gRate,
      gSize: t.gSize,
      gContour: t.gContour,
      gWarp: t.gWarp,
      gSpray: t.gSpray,
      resonance: t.resonance,
      decay: t.decay,
      fPitch: t.fPitch,
      slope: t.slope,
      drive: t.drive,
      compress: t.compress,
      crush: t.crush,
      delayAmt: t.delayAmt,
      delayTime: t.delayTime,
      delayFeedback: t.delayFeedback,
      reverbAmt: t.reverbAmt,
      reverbSize: t.reverbSize,
      reverbDecay: t.reverbDecay,
      tone: t.tone,
      spread: t.spread,
      muted: t.muted,
      soloed: t.soloed,
      automationEvents: t.automationEvents // save automation sequences!
    })),
    microcosm: {
      activity: state.microcosm.activity,
      shape: state.microcosm.shape,
      filter: state.microcosm.filter,
      mix: state.microcosm.mix,
      time: state.microcosm.time,
      repeats: state.microcosm.repeats,
      space: state.microcosm.space,
      loopLevel: state.microcosm.loopLevel,
      modRate: state.microcosm.modRate,
      modDepth: state.microcosm.modDepth,
      reverbTime: state.microcosm.reverbTime,
      bypass: state.microcosm.bypass,
      preset: state.microcosm.preset,
      isPlaybackActive: state.microcosm.isPlaybackActive,
      automationEvents: state.microcosm.automationEvents // save microcosm automation loops!
    }
  };

  if (state.activePresetIndex >= 0 && state.presets[state.activePresetIndex].name === name) {
    state.presets[state.activePresetIndex] = newPresetData;
    showNotification(`Updated Preset: ${name}`);
  } else {
    state.presets.push(newPresetData);
    state.activePresetIndex = state.presets.length - 1;
    showNotification(`Saved Preset: ${name}`);
  }

  saveLocalPresets();
  updatePresetDropdown();
}

function deletePreset() {
  if (state.activePresetIndex < 0) {
    showNotification("No saved preset selected to delete", "error");
    return;
  }
  
  const deletedName = state.presets[state.activePresetIndex].name;
  state.presets.splice(state.activePresetIndex, 1);
  state.activePresetIndex = -1;
  
  saveLocalPresets();
  updatePresetDropdown();
  loadPreset(-1); // Reset
  showNotification(`Deleted Preset: ${deletedName}`);
}

function exportPresets() {
  if (state.presets.length === 0) {
    showNotification("No presets available to export", "error");
    return;
  }

  const fileData = JSON.stringify(state.presets, null, 2);
  const blob = new Blob([fileData], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  
  const a = document.createElement('a');
  a.href = url;
  a.download = `torso-s4-presets-v2-${new Date().toISOString().slice(0, 10)}.json`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
  
  showNotification("Presets exported successfully!");
}

function importPresets(file) {
  const reader = new FileReader();
  reader.onload = (e) => {
    try {
      const imported = JSON.parse(e.target.result);
      if (Array.isArray(imported)) {
        const valid = imported.every(p => p.name && Array.isArray(p.tracks));
        if (valid) {
          state.presets = state.presets.concat(imported);
          saveLocalPresets();
          updatePresetDropdown();
          showNotification(`Imported ${imported.length} presets!`);
        } else {
          showNotification("Invalid file structure. Presets not imported.", "error");
        }
      } else {
        showNotification("Invalid file format. Presets not imported.", "error");
      }
    } catch (err) {
      showNotification("Error parsing JSON file.", "error");
    }
  };
  reader.readAsText(file);
}

// --- Global Event Setup ---
function setupGlobalEvents() {
  // Transport Play Button
  el.globalPlayBtn.addEventListener('click', toggleTransport);

  // BPM Slider change
  el.globalBpm.addEventListener('input', () => {
    transport.bpm = parseInt(el.globalBpm.value);
    el.globalBpmVal.textContent = transport.bpm;
    updateLoopDuration();
  });

  // Loop Size (Bars) change
  el.globalLoopBars.addEventListener('change', () => {
    transport.loopBars = parseInt(el.globalLoopBars.value);
    updateLoopDuration();
    // reset playhead to 0 if it exceeds the new loop length
    if (transport.playheadMs >= transport.totalDurationMs) {
      transport.playheadMs = 0;
    }
  });

  // MIDI Device Selection
  el.midiDeviceSelect.addEventListener('change', () => {
    const selectedId = el.midiDeviceSelect.value;
    if (!selectedId) {
      state.midiOutput = null;
      updateMidiDevices();
      return;
    }
    
    const outputs = Array.from(state.midiAccess.outputs.values());
    const matched = outputs.find(out => out.id === selectedId);
    if (matched) {
      state.midiOutput = matched;
      updateMidiDevices();
      showNotification(`Output routed to ${matched.name}`);
    }
  });

  if (el.microcosmDeviceSelect) {
    el.microcosmDeviceSelect.addEventListener('change', () => {
      const selectedId = el.microcosmDeviceSelect.value;
      if (!selectedId) {
        state.microcosmOutput = null;
        updateMidiDevices();
        return;
      }
      
      const outputs = Array.from(state.midiAccess.outputs.values());
      const matched = outputs.find(out => out.id === selectedId);
      if (matched) {
        state.microcosmOutput = matched;
        updateMidiDevices();
        showNotification(`Microcosm routed to ${matched.name}`);
      }
    });
  }

  // Preset Selection
  el.presetSelect.addEventListener('change', () => {
    const val = el.presetSelect.value;
    if (val === "") {
      loadPreset(-1);
    } else {
      loadPreset(parseInt(val));
    }
  });

  el.savePresetBtn.addEventListener('click', savePreset);
  el.deletePresetBtn.addEventListener('click', deletePreset);
  el.exportPresetBtn.addEventListener('click', exportPresets);
  el.panicBtn.addEventListener('click', triggerPanic);
  el.importPresetFile.addEventListener('change', (e) => {
    if (e.target.files && e.target.files[0]) {
      importPresets(e.target.files[0]);
    }
  });
}

// --- MIDI Panic & System Reset ---
function triggerPanic() {
  // 1. Stop transport if active
  if (transport.isPlaying) {
    toggleTransport();
  }

  // 2. Clear playhead timeline position
  transport.playheadMs = 0;
  updateTimelineUI();

  // 3. Reset all track parameters in state to default init
  state.tracks.forEach(track => {
    const defaults = DEFAULT_TRACK_PARAMS();
    Object.assign(track, defaults);
  });

  // Reset Microcosm state
  const defaultMC = {
    activity: 0,
    shape: 0,
    filter: 64,
    mix: 64,
    time: 64,
    repeats: 64,
    space: 0,
    loopLevel: 64,
    modRate: 0,
    modDepth: 0,
    reverbTime: 64,
    bypass: false,
    preset: 1,
    isRecording: false,
    isPlaybackActive: true,
    automationEvents: []
  };
  Object.assign(state.microcosm, defaultMC);

  // 4. Send MIDI Panic messages (CC 120 All Sound Off + CC 123 All Notes Off)
  // Send to all 4 track channels + Channel 16 to silence S4
  const targetChannels = [1, 2, 3, 4, 16];
  targetChannels.forEach(chan => {
    sendCC(chan, 120, 0); // All Sound Off
    sendCC(chan, 123, 0); // All Notes Off
  });

  // Send bypass CC to Microcosm (CC 102 value 0 to bypass)
  sendMicrocosmCC(102, 0);

  // 5. Transmit default parameter values to hardware to reset parameters
  transmitAllParameters();
  transmitMicrocosmAll();

  // 6. Update all UI visual knobs and faders
  updateAllVisuals();
  
  showNotification("Panic Triggered: MIDI Silenced & Reset to Init", "error");
}

// --- Toast Notifications Helper ---
let notificationTimeout;
function showNotification(message, type = "success") {
  clearTimeout(notificationTimeout);
  el.notification.textContent = message;
  el.notification.className = "notification";
  
  if (type === "error") {
    el.notification.style.borderColor = "var(--accent-red)";
    el.notification.style.boxShadow = "var(--shadow-lg), 0 0 15px var(--accent-red-glow)";
  } else {
    el.notification.style.borderColor = "var(--accent-amber)";
    el.notification.style.boxShadow = "var(--shadow-lg), 0 0 15px var(--accent-amber-glow)";
  }
  
  el.notification.classList.remove('hidden');
  notificationTimeout = setTimeout(() => {
    el.notification.classList.add('hidden');
  }, 3500);
}
