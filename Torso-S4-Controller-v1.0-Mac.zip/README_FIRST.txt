=============================================================================
 TORSO S4 MIDI CONTROLLER & PRESET DECK
 Created by Pablo Arellano
 Website: https://www.pabloarellano.org
 Support & Inquiries: aztecbird@mac.com
=============================================================================

Thank you for your support!

QUICKSTART (MAC):
1. Double-click "Torso S4 Controller.app" (or double-click "start.command").
2. Your browser will automatically launch at:
   http://localhost:8084
3. In the top-right header, select your S4 MIDI Output interface.
4. Optional: If you also run a Hologram Microcosm pedal in your rig, select your
   Microcosm MIDI Out to control both devices from one unified command center!
5. Shape sounds using the physical knobs, vertical faders, and context encoders.
6. Use the Global Transport to record and loop multi-parameter CC automation
   in sync with your hardware!

HARDWARE SETUP TIP (TORSO ELECTRONICS S4):
To allow the controller to modulate parameters over USB-MIDI or 5-pin DIN:
1. Connect your S4 to your Mac via USB (class-compliant).
2. On the hardware S4, press [CONFIG].
3. Navigate to MIDI and ensure CC CONTROL is set to ON.
4. Navigate to TRACK -> MIDI CHANNEL and verify Tracks 1 to 4 match MIDI
   Channels 1, 2, 3, and 4 (standard default).

KEY FEATURES:
- 4-Track tactile channel strip layout:
  * Material Volume Level (CC 56)
  * Resonant Filter Cutoff (CC 78)
  * Auxiliary Sends 1–4 (CC 10, 11, 12, 13)
  * 5 Context Hardware Encoders (CC 14, 15, 16, 17, 18)
- Real-time Multi-Track Automation Loop Recorder:
  * Record knob motions across 4, 8, 16, 32, 64, or 128 bars.
  * Live playhead timeline visualizer and tempo sync (40–240 BPM).
- Dual-Device Command Deck:
  * Simultaneous control for Torso S4 and Hologram Microcosm.
- Preset Library Manager:
  * Save layouts locally, export portable .json backups, and share preset banks.

SUPPORT & INQUIRIES:
Email: aztecbird@mac.com
Website: https://www.pabloarellano.org
=============================================================================
