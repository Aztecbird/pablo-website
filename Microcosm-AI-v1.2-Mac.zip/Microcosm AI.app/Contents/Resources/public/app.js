// Microcosm AI Frontend Controller & Dynamic Rules Engine (v1.2 Keyboard Split & Register Tracking)

const CC_ACTIVITY = 25;
const CC_REPEATS  = 26;
const CC_TIME     = 27;
const CC_MIX      = 28;
const CC_SPACE    = 29;
const CC_FILTER   = 30;

// State
let ws = null;
let isEnabled = false;
let isPaused = false;
let currentAlgorithm = { id: 0, name: "WARP" };

// Baseline Snapshots
const defaultSnapshot = {
  mix: 64,
  space: 51,
  filter: 64,
  activity: 45,
  repeats: 60,
  time: 64
};

let currentValues = { ...defaultSnapshot };
let targetValues = { ...defaultSnapshot };

// Active Rule Structure with Pitch Register Awareness (C4 = Note 60)
let activeRule = {
  mode: "COMBINE",
  algorithm: "WARP",
  explanation: "Register-aware: Notes below Middle C (C4) trigger dramatic low-end filter resonance and sustained repeats. Notes above C4 create bright, sparkling textures with shimmer.",
  ranges: {
    mix: { min: 20, max: 95 },
    space: { min: 15, max: 110 },
    filter: { min: 20, max: 125 },
    activity: { min: 10, max: 115 },
    repeats: { min: 15, max: 120 },
    time: { min: 20, max: 110 }
  },
  evolve: {
    enabled: true,
    targetParam: "filter",
    direction: -1,
    durationSec: 60,
    startTime: Date.now()
  },
  follow: {
    quietVelocityThreshold: 55,
    busyDensityThreshold: 4
  }
};

let recentNotes = [];
let lastVelocity = 0;
let lastNote = 60;

// DOM Elements
const statusDot = document.getElementById('statusDot');
const statusText = document.getElementById('statusText');
const destSelect = document.getElementById('destSelect');
const srcSelect = document.getElementById('srcSelect');
const channelSelect = document.getElementById('channelSelect');

const enableBtn = document.getElementById('enableBtn');
const enableLabel = document.getElementById('enableLabel');
const enableIcon = document.getElementById('enableIcon');
const pauseBtn = document.getElementById('pauseBtn');
const restoreBtn = document.getElementById('restoreBtn');

const promptInput = document.getElementById('promptInput');
const applyPromptBtn = document.getElementById('applyPromptBtn');
const planExplanation = document.getElementById('planExplanation');
const planMode = document.getElementById('planMode');

// Sliders & Displays
const params = ['Mix', 'Space', 'Filter', 'Activity', 'Repeats', 'Time'];
const dom = {};
params.forEach(p => {
  dom[`slider${p}`] = document.getElementById(`slider${p}`);
  dom[`val${p}`] = document.getElementById(`val${p}`);
  dom[`act${p}`] = document.getElementById(`act${p}`);
  dom[`min${p}`] = document.getElementById(`min${p}`);
  dom[`max${p}`] = document.getElementById(`max${p}`);
});

const hudMidiIn = document.getElementById('hudMidiIn');
const hudDensity = document.getElementById('hudDensity');
const hudEngine = document.getElementById('hudEngine');

function initWebSocket() {
  const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
  ws = new WebSocket(`${protocol}//${window.location.host}`);

  ws.onopen = () => {
    statusDot.classList.add('online');
    statusText.innerText = 'Connected (CoreMIDI Live)';
    ws.send(JSON.stringify({ type: 'refresh_devices' }));
  };

  ws.onclose = () => {
    statusDot.classList.remove('online');
    statusText.innerText = 'Reconnecting Engine...';
    setTimeout(initWebSocket, 2000);
  };

  ws.onmessage = (event) => {
    try {
      const data = JSON.parse(event.data);
      handleMessage(data);
    } catch (e) {
      console.error("WS Parse error:", e);
    }
  };
}

function handleMessage(msg) {
  if (msg.type === 'devices') {
    populateDevices(msg.destinations, msg.sources);
  } else if (msg.type === 'note_on') {
    handleNoteOn(msg.note, msg.velocity);
  } else if (msg.type === 'status') {
    hudEngine.innerText = msg.msg;
  }
}

function populateDevices(destinations, sources) {
  destSelect.innerHTML = '';
  srcSelect.innerHTML = '';

  destinations.forEach((d) => {
    const opt = document.createElement('option');
    opt.value = d.id;
    opt.innerText = `[${d.id}] ${d.name}`;
    if (d.name.toLowerCase().includes('umc1820')) opt.selected = true;
    destSelect.appendChild(opt);
  });

  sources.forEach((s) => {
    const opt = document.createElement('option');
    opt.value = s.id;
    opt.innerText = `[${s.id}] ${s.name}`;
    if (s.name.toLowerCase().includes('casio')) opt.selected = true;
    srcSelect.appendChild(opt);
  });

  updatePorts();
}

function updatePorts() {
  if (!ws || ws.readyState !== WebSocket.OPEN) return;
  ws.send(JSON.stringify({
    type: 'select_ports',
    dest: parseInt(destSelect.value, 10) || 0,
    src: parseInt(srcSelect.value, 10) || 0,
    channel: parseInt(channelSelect.value, 10) || 0
  }));
}

destSelect.addEventListener('change', updatePorts);
srcSelect.addEventListener('change', updatePorts);
channelSelect.addEventListener('change', updatePorts);

function sendCC(cc, val) {
  if (!ws || ws.readyState !== WebSocket.OPEN) return;
  ws.send(JSON.stringify({
    type: 'send_cc',
    cc: cc,
    value: Math.round(val),
    channel: parseInt(channelSelect.value, 10) || 0
  }));
}

function sendProgramChange(prog) {
  if (!ws || ws.readyState !== WebSocket.OPEN) return;
  ws.send(JSON.stringify({
    type: 'send_pc',
    program: prog,
    channel: parseInt(channelSelect.value, 10) || 0
  }));
}

window.selectAlgorithm = function(progId, name) {
  currentAlgorithm = { id: progId, name: name };
  document.querySelectorAll('.algo-btn').forEach(b => {
    if (b.innerText.includes(name)) b.classList.add('active');
    else b.classList.remove('active');
  });

  sendProgramChange(progId);
  hudEngine.innerText = `${name} (Program ${progId}) selected on pedal`;
  
  if (name === 'WARP') setPresetPrompt('warp_glitch');
  else if (name === 'INTERRUPT') setPresetPrompt('interrupt_chaos');
  else if (name === 'TUNNEL') setPresetPrompt('tunnel_reverb');
  else if (name === 'MAZE') setPresetPrompt('maze_delay');
};

function noteToName(n) {
  const names = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'];
  const octave = Math.floor(n / 12) - 1;
  return `${names[n % 12]}${octave}`;
}

// Handle Incoming Keys with Register Detection (C4 = 60)
function handleNoteOn(note, velocity) {
  const now = Date.now();
  recentNotes.push({ time: now, vel: velocity, note: note });
  lastVelocity = velocity;
  lastNote = note;

  const noteStr = noteToName(note);
  const register = note < 60 ? "Bass / Dramatic" : "Treble / Bright";
  hudMidiIn.innerText = `${noteStr} (#${note}) • Vel ${velocity} [${register}]`;

  if (!isEnabled || isPaused) return;

  applyAdaptiveRules(note, velocity);
}

function applyAdaptiveRules(note, velocity) {
  const r = activeRule.ranges;

  // 1. PITCH REGISTER TRACKING (Pivot around Middle C / C4 = Note 60)
  if (note < 60) {
    // Going DOWN from C4: Dramatic, dark, resonant, deep repeats
    // The lower the note, the darker and more dramatic
    const depth = (60 - note) / 36; // scale for lower 3 octaves
    targetValues.filter = Math.max(r.filter.min, 60 - depth * 35); // pulls filter into warm, dark low-pass (e.g. 25-45)
    targetValues.repeats = Math.min(r.repeats.max, 65 + depth * 45); // longer, looming decay
    targetValues.space = Math.min(r.space.max, 55 + depth * 40);     // cavernous depth
    targetValues.activity = Math.max(r.activity.min, 40 + depth * 30); // heavier sub-pulse grains
  } else {
    // Going UP from C4: Bright, cheerful, airy, open filter
    // The higher the note, the brighter and lighter
    const rise = (note - 60) / 36; // scale for upper octaves
    targetValues.filter = Math.min(r.filter.max, 68 + rise * 50); // opens filter up towards high-pass sparkle (80-120)
    targetValues.space = Math.min(r.space.max, 45 + rise * 55);   // bright, airy shimmer
    targetValues.repeats = Math.max(r.repeats.min, 50 - rise * 20); // lighter, cleaner repeats
    targetValues.activity = Math.min(r.activity.max, 50 + rise * 40); // delicate fluttering grains
  }

  // 2. STRIKE VELOCITY DYNAMICS (Touch sensitivity layered on top)
  if (velocity < activeRule.follow.quietVelocityThreshold) {
    // Soft touch further expands reverb wash
    targetValues.space = Math.min(r.space.max, targetValues.space + 18);
  } else if (velocity > 85) {
    // Hard strike reins in mix to maintain definition
    targetValues.mix = Math.max(r.mix.min, defaultSnapshot.mix - 15);
  } else {
    targetValues.mix = defaultSnapshot.mix;
  }
}

// Background Smoothing loop at 40Hz (25ms)
setInterval(() => {
  const now = Date.now();
  recentNotes = recentNotes.filter(n => now - n.time < 1500);
  const density = (recentNotes.length / 1.5).toFixed(1);
  hudDensity.innerText = `Last Vel: ${lastVelocity || '--'} | Density: ${density} notes/s`;

  if (isEnabled && !isPaused) {
    const smoothFactor = 0.08;
    let changed = false;

    const keys = ['mix', 'space', 'filter', 'activity', 'repeats', 'time'];
    keys.forEach(k => {
      const diff = targetValues[k] - currentValues[k];
      if (Math.abs(diff) > 0.5) {
        currentValues[k] += diff * smoothFactor;
        changed = true;
      }
    });

    if (changed) {
      updateUI();
      sendCC(CC_MIX, currentValues.mix);
      sendCC(CC_SPACE, currentValues.space);
      sendCC(CC_FILTER, currentValues.filter);
      sendCC(CC_ACTIVITY, currentValues.activity);
      sendCC(CC_REPEATS, currentValues.repeats);
      sendCC(CC_TIME, currentValues.time);
    }
  }
}, 25);

function updateUI() {
  dom.valMix.innerHTML = `${Math.round((currentValues.mix / 127) * 100)}<span>%</span>`;
  dom.valSpace.innerHTML = `${Math.round((currentValues.space / 127) * 100)}<span>%</span>`;
  dom.valFilter.innerHTML = `${Math.round(currentValues.filter)}`;
  dom.valActivity.innerHTML = `${Math.round(currentValues.activity)}`;
  dom.valRepeats.innerHTML = `${Math.round(currentValues.repeats)}`;
  dom.valTime.innerHTML = `${Math.round(currentValues.time)}`;

  ['Mix', 'Space', 'Filter', 'Activity', 'Repeats', 'Time'].forEach(p => {
    const k = p.toLowerCase();
    dom[`slider${p}`].value = currentValues[k];
    dom[`act${p}`].style.width = `${(currentValues[k] / 127) * 100}%`;
  });
}

// Sliders listeners
['Mix', 'Space', 'Filter', 'Activity', 'Repeats', 'Time'].forEach(p => {
  const k = p.toLowerCase();
  dom[`slider${p}`].addEventListener('input', (e) => {
    currentValues[k] = parseFloat(e.target.value);
    targetValues[k] = currentValues[k];
    updateUI();
    const ccMap = {
      mix: CC_MIX, space: CC_SPACE, filter: CC_FILTER,
      activity: CC_ACTIVITY, repeats: CC_REPEATS, time: CC_TIME
    };
    sendCC(ccMap[k], currentValues[k]);
  });
});

enableBtn.addEventListener('click', () => {
  isEnabled = !isEnabled;
  if (isEnabled) {
    isPaused = false;
    enableBtn.classList.add('running');
    enableIcon.innerText = '◼';
    enableLabel.innerText = 'Stop Automation';
    pauseBtn.innerText = '⏸ Pause';
    activeRule.evolve.startTime = Date.now();
    hudEngine.innerText = `Active: ${currentAlgorithm.name} Following C4 Splits`;
  } else {
    enableBtn.classList.remove('running');
    enableIcon.innerText = '▶';
    enableLabel.innerText = 'Enable Follow';
    hudEngine.innerText = 'Automation Stopped';
  }
});

pauseBtn.addEventListener('click', () => {
  if (!isEnabled) return;
  isPaused = !isPaused;
  if (isPaused) {
    pauseBtn.innerText = '▶ Resume';
    hudEngine.innerText = 'Paused: Parameters Frozen';
  } else {
    pauseBtn.innerText = '⏸ Pause';
    hudEngine.innerText = 'Resumed active automation';
  }
});

restoreBtn.addEventListener('click', () => {
  currentValues = { ...defaultSnapshot };
  targetValues = { ...defaultSnapshot };
  updateUI();
  sendCC(CC_MIX, defaultSnapshot.mix);
  sendCC(CC_SPACE, defaultSnapshot.space);
  sendCC(CC_FILTER, defaultSnapshot.filter);
  sendCC(CC_ACTIVITY, defaultSnapshot.activity);
  sendCC(CC_REPEATS, defaultSnapshot.repeats);
  sendCC(CC_TIME, defaultSnapshot.time);
  hudEngine.innerText = 'Restored starting baseline snapshot';
});

// Prompt Interpreter
function interpretPrompt(text) {
  const lower = text.toLowerCase();
  let mode = "COMBINE";
  let explanation = "";

  let rMix = { min: 25, max: 90 };
  let rSpace = { min: 20, max: 120 };
  let rFilter = { min: 20, max: 125 };
  let rActivity = { min: 10, max: 115 };
  let rRepeats = { min: 15, max: 120 };
  let rTime = { min: 20, max: 110 };

  let algoName = currentAlgorithm.name;
  if (lower.includes('warp')) algoName = "WARP";
  else if (lower.includes('interrupt')) algoName = "INTERRUPT";
  else if (lower.includes('tunnel')) algoName = "TUNNEL";
  else if (lower.includes('maze')) algoName = "MAZE";

  explanation = `C4 Split Active (${algoName}): Notes below C4 dive into dark, dramatic filter resonance with sustained repeats; notes above C4 open into bright, cheerful, sparkling highs.`;

  return {
    mode: mode,
    algorithm: algoName,
    explanation: explanation,
    ranges: { mix: rMix, space: rSpace, filter: rFilter, activity: rActivity, repeats: rRepeats, time: rTime },
    evolve: { enabled: true, targetParam: 'filter', durationSec: 60, startTime: Date.now() },
    follow: { quietVelocityThreshold: 55, busyDensityThreshold: 4 }
  };
}

applyPromptBtn.addEventListener('click', () => {
  const text = promptInput.value.trim();
  if (!text) return;
  activeRule = interpretPrompt(text);
  planMode.innerText = `MODE: ${activeRule.mode} • ALGORITHM: ${activeRule.algorithm}`;
  planExplanation.innerText = activeRule.explanation;

  params.forEach(p => {
    const k = p.toLowerCase();
    dom[`min${p}`].innerText = activeRule.ranges[k].min;
    dom[`max${p}`].innerText = activeRule.ranges[k].max;
  });
});

window.setPresetPrompt = function(presetKey) {
  if (presetKey === 'warp_glitch') {
    promptInput.value = "In Warp, low notes under C4 get dramatic and dark, high notes get bright and cheerful";
  } else if (presetKey === 'interrupt_chaos') {
    promptInput.value = "In Interrupt, low notes stutter with heavy repeats, high notes create light cheerful glitch patterns";
  } else if (presetKey === 'tunnel_reverb') {
    promptInput.value = "In Tunnel, notes below C4 create deep dark bass washes, high notes shimmer brightly";
  } else if (presetKey === 'maze_delay') {
    promptInput.value = "In Maze, low notes trigger dramatic long multi-taps, high notes trigger cheerful short rhythm delays";
  }
  applyPromptBtn.click();
};

initWebSocket();
updateUI();
