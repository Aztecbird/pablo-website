#!/bin/bash
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd "$DIR"

# Kill any existing server on 3880
lsof -ti :3880 | xargs kill -9 2>/dev/null

# Open browser after a brief delay
(sleep 1.2 && open "http://localhost:3880") &

# Run server
/usr/local/bin/node server.js || node server.js
