const http = require('http');
const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');
const WebSocket = require('ws');

const PORT = 3880;

const bridge = spawn(path.join(__dirname, 'midi_bridge'), [], {
    stdio: ['pipe', 'pipe', 'inherit']
});

bridge.stdout.setEncoding('utf8');

const server = http.createServer((req, res) => {
    let filePath = path.join(__dirname, 'public', req.url === '/' ? 'index.html' : req.url);
    const ext = path.extname(filePath);
    const contentTypes = {
        '.html': 'text/html',
        '.js': 'application/javascript',
        '.css': 'text/css',
        '.json': 'application/json'
    };

    fs.readFile(filePath, (err, content) => {
        if (err) {
            if (err.code === 'ENOENT') {
                res.writeHead(404, { 'Content-Type': 'text/plain' });
                res.end('404 Not Found');
            } else {
                res.writeHead(500);
                res.end(`Server Error: ${err.code}`);
            }
        } else {
            res.writeHead(200, { 'Content-Type': contentTypes[ext] || 'text/plain' });
            res.end(content);
        }
    });
});

const wss = new WebSocket.Server({ server });

function broadcast(data) {
    const msg = typeof data === 'string' ? data : JSON.stringify(data);
    wss.clients.forEach(client => {
        if (client.readyState === WebSocket.OPEN) {
            client.send(msg);
        }
    });
}

let stdoutBuffer = '';
bridge.stdout.on('data', (chunk) => {
    stdoutBuffer += chunk;
    let lines = stdoutBuffer.split('\n');
    stdoutBuffer = lines.pop();
    for (const line of lines) {
        if (line.trim().length > 0) {
            try {
                const parsed = JSON.parse(line.trim());
                broadcast(parsed);
            } catch (e) {
                console.log("[Bridge raw]", line);
            }
        }
    }
});

wss.on('connection', (ws) => {
    console.log('[WS] Client connected');
    bridge.stdin.write('LIST\n');

    ws.on('message', (message) => {
        try {
            const data = JSON.parse(message.toString());
            if (data.type === 'send_cc') {
                const ch = data.channel !== undefined ? data.channel : 0;
                bridge.stdin.write(`CC ${data.cc} ${Math.round(data.value)} ${ch}\n`);
            } else if (data.type === 'send_pc') {
                const ch = data.channel !== undefined ? data.channel : 0;
                bridge.stdin.write(`PC ${Math.round(data.program)} ${ch}\n`);
            } else if (data.type === 'select_ports') {
                bridge.stdin.write(`SELECT ${data.dest} ${data.src} ${data.channel || 0}\n`);
            } else if (data.type === 'refresh_devices') {
                bridge.stdin.write('LIST\n');
            }
        } catch (e) {
            console.error('Error handling WS message:', e);
        }
    });
});

server.listen(PORT, '127.0.0.1', () => {
    console.log(`Microcosm AI Companion running on http://127.0.0.1:${PORT}`);
});

process.on('SIGINT', () => {
    bridge.kill();
    process.exit();
});
