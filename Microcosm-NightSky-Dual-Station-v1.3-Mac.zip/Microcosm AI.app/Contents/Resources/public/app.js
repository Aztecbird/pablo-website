// Microcosm + NightSky Dual Pedal Companion Engine

// Hologram Microcosm (Channel 1 -> ch index 0)
const MC_CH = 0;
const MC_CC_ACTIVITY = 25;
const MC_CC_REPEATS  = 26;
const MC_CC_MIX      = 28;
const MC_CC_SPACE    = 29;
const MC_CC_FILTER   = 30;

// Strymon NightSky (Channel 2 -> ch index 1)
const NS_CH = 1;
const NS_CC_MIX      = 15;
const NS_CC_DECAY    = 17;
const NS_CC_FILTER   = 21;
const NS_CC_SHIMMER  = 26;
const NS_CC_FREEZE   = 70;

// State
let ws = null;
let isEnabled = false;
let isPaused = false;
let isNsFrozen = false;
let currentAlgorithm = { id: 0, name: "WARP" };

// Parameter values store
let currentValues = {
  // Microcosm
  mcMix: 64, mcSpace: 51, mcFilter: 64, mcActivity: 45,
  // NightSky
  nsMix: 64, nsDecay: 70, nsFilter: 65, nsShimmer: 40
};

let targetValues = { ...currentValues };
const defaultSnapshot = { ...currentValues };

let recentNotes = [];
let lastVelocity = 0;
let lastNote = 60;

// DOM Elements
const statusDot = document.getElementById('statusDot');
const statusText = document.getElementById('statusText');
const destSelect = document.getElementById('destSelect');
const srcSelect = document.getElementById('srcSelect');

const enableBtn = document.getElementById('enableBtn');
const enableLabel = document.getElementById('enableLabel');
const enableIcon = document.getElementById('enableIcon');
const pauseBtn = document.getElementById('pauseBtn');
const restoreBtn = document.getElementById('restoreBtn');
const nsFreezeBtn = document.getElementById('nsFreezeBtn');

const hudMidiIn = document.getElementById('hudMidiIn');
const hudDensity = document.getElementById('hudDensity');
const hudEngine = document.getElementById('hudEngine');

// Dual Sliders
const sliderIds = ['McMix', 'McSpace', 'McFilter', 'McActivity', 'NsMix', 'NsDecay', 'NsFilter', 'NsShimmer'];
const dom = {};
sliderIds.forEach(id => {
  dom[`slider${id}`] = document.getElementById(`slider${id}`);
  dom[`val${id}`] = document.getElementById(`val${id}`);
  dom[`act${id}`] = document.getElementById(`act${id}`);
});

function initWebSocket() {
  const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
  ws = new WebSocket(`${protocol}//${window.location.host}`);

  ws.onopen = () => {
    statusDot.classList.add('online');
    statusText.innerText = 'Connected (CoreMIDI Live)';
    ws.send(JSON.stringify({ type: 'refresh_devices' }));
  };

  ws.onclose = () => {
    statusDot.classList.remove('online');
    statusText.innerText = 'Reconnecting Engine...';
    setTimeout(initWebSocket, 2000);
  };

  ws.onmessage = (event) => {
    try {
      const data = JSON.parse(event.data);
      handleMessage(data);
    } catch (e) {
      console.error("WS Parse error:", e);
    }
  };
}

function handleMessage(msg) {
  if (msg.type === 'devices') {
    populateDevices(msg.destinations, msg.sources);
  } else if (msg.type === 'note_on') {
    handleNoteOn(msg.note, msg.velocity);
  } else if (msg.type === 'status') {
    hudEngine.innerText = msg.msg;
  }
}

function populateDevices(destinations, sources) {
  destSelect.innerHTML = '';
  srcSelect.innerHTML = '';

  destinations.forEach((d) => {
    const opt = document.createElement('option');
    opt.value = d.id;
    opt.innerText = `[${d.id}] ${d.name}`;
    if (d.name.toLowerCase().includes('umc1820')) opt.selected = true;
    destSelect.appendChild(opt);
  });

  sources.forEach((s) => {
    const opt = document.createElement('option');
    opt.value = s.id;
    opt.innerText = `[${s.id}] ${s.name}`;
    if (s.name.toLowerCase().includes('casio')) opt.selected = true;
    srcSelect.appendChild(opt);
  });

  updatePorts();
}

function updatePorts() {
  if (!ws || ws.readyState !== WebSocket.OPEN) return;
  ws.send(JSON.stringify({
    type: 'select_ports',
    dest: parseInt(destSelect.value, 10) || 0,
    src: parseInt(srcSelect.value, 10) || 0,
    channel: 0
  }));
}

destSelect.addEventListener('change', updatePorts);
srcSelect.addEventListener('change', updatePorts);

function sendCC(channel, cc, val) {
  if (!ws || ws.readyState !== WebSocket.OPEN) return;
  ws.send(JSON.stringify({
    type: 'send_cc',
    channel: channel,
    cc: cc,
    value: Math.round(val)
  }));
}

function sendProgramChange(channel, prog) {
  if (!ws || ws.readyState !== WebSocket.OPEN) return;
  ws.send(JSON.stringify({
    type: 'send_pc',
    channel: channel,
    program: prog
  }));
}

window.selectAlgorithm = function(progId, name) {
  currentAlgorithm = { id: progId, name: name };
  document.querySelectorAll('.algo-btn').forEach(b => {
    if (b.innerText.includes(name)) b.classList.add('active');
    else b.classList.remove('active');
  });

  sendProgramChange(MC_CH, progId);
  hudEngine.innerText = `Microcosm: ${name} (Prog ${progId}) selected`;
};

window.toggleNightSkyFreeze = function() {
  isNsFrozen = !isNsFrozen;
  if (isNsFrozen) {
    nsFreezeBtn.classList.add('latched');
    nsFreezeBtn.innerText = '♾ Infinite Freeze LATCHED (Active)';
    sendCC(NS_CH, NS_CC_FREEZE, 127);
  } else {
    nsFreezeBtn.classList.remove('latched');
    nsFreezeBtn.innerText = '♾ Infinite Reverb Freeze (CC 70)';
    sendCC(NS_CH, NS_CC_FREEZE, 0);
  }
};

function noteToName(n) {
  const names = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'];
  const octave = Math.floor(n / 12) - 1;
  return `${names[n % 12]}${octave}`;
}

// Unified Pitch Tracking Across Both Pedals (C4 = 60)
function handleNoteOn(note, velocity) {
  const now = Date.now();
  recentNotes.push({ time: now, vel: velocity, note: note });
  lastVelocity = velocity;
  lastNote = note;

  const noteStr = noteToName(note);
  const reg = note < 60 ? "Bass / Dramatic" : "Treble / Bright Shimmer";
  hudMidiIn.innerText = `${noteStr} (#${note}) • Vel ${velocity} [${reg}]`;

  if (!isEnabled || isPaused) return;

  applyDualAdaptiveRules(note, velocity);
}

function applyDualAdaptiveRules(note, velocity) {
  // PITCH TRACKING AROUND C4 (60)
  if (note < 60) {
    // LOWER KEYS:
    // Microcosm: Dark, resonant low-pass filter, heavier granular activity
    const depth = (60 - note) / 36;
    targetValues.mcFilter = Math.max(25, 60 - depth * 35);
    targetValues.mcSpace = Math.min(105, 50 + depth * 40);
    targetValues.mcActivity = Math.max(30, 45 + depth * 30);

    // NightSky: Massive deep decay, darker low-pass filter, low shimmer
    targetValues.nsDecay = Math.min(115, 75 + depth * 40);
    targetValues.nsFilter = Math.max(30, 65 - depth * 30);
    targetValues.nsShimmer = Math.max(10, 30 - depth * 20);
  } else {
    // UPPER KEYS:
    // Microcosm: Bright open filter, delicate fluttering grains
    const rise = (note - 60) / 36;
    targetValues.mcFilter = Math.min(120, 68 + rise * 50);
    targetValues.mcSpace = Math.min(110, 45 + rise * 55);
    targetValues.mcActivity = Math.min(110, 45 + rise * 45);

    // NightSky: Crystalline Shimmer, open sparkling highs
    targetValues.nsFilter = Math.min(125, 70 + rise * 50);
    targetValues.nsShimmer = Math.min(115, 45 + rise * 60); // Harmonic Shimmer blooms!
    targetValues.nsDecay = Math.max(45, 65 - rise * 20);
  }

  // VELOCITY DYNAMICS
  if (velocity < 55) {
    // Soft touch -> bloom reverb mix on both
    targetValues.mcSpace = Math.min(115, targetValues.mcSpace + 15);
    targetValues.nsMix = Math.min(95, targetValues.nsMix + 15);
  } else if (velocity > 85) {
    // Heavy strikes -> back off wet mix slightly to retain attack
    targetValues.mcMix = Math.max(30, defaultSnapshot.mcMix - 15);
    targetValues.nsMix = Math.max(30, defaultSnapshot.nsMix - 15);
  } else {
    targetValues.mcMix = defaultSnapshot.mcMix;
    targetValues.nsMix = defaultSnapshot.nsMix;
  }
}

// Smoothing loop at 40Hz
setInterval(() => {
  const now = Date.now();
  recentNotes = recentNotes.filter(n => now - n.time < 1500);
  const density = (recentNotes.length / 1.5).toFixed(1);
  hudDensity.innerText = `Last Vel: ${lastVelocity || '--'} | Density: ${density} notes/s`;

  if (isEnabled && !isPaused) {
    const smoothFactor = 0.08;
    let changed = false;

    const allKeys = ['mcMix', 'mcSpace', 'mcFilter', 'mcActivity', 'nsMix', 'nsDecay', 'nsFilter', 'nsShimmer'];
    allKeys.forEach(k => {
      const diff = targetValues[k] - currentValues[k];
      if (Math.abs(diff) > 0.5) {
        currentValues[k] += diff * smoothFactor;
        changed = true;
      }
    });

    if (changed) {
      updateUI();
      // Send Microcosm (Ch 1)
      sendCC(MC_CH, MC_CC_MIX, currentValues.mcMix);
      sendCC(MC_CH, MC_CC_SPACE, currentValues.mcSpace);
      sendCC(MC_CH, MC_CC_FILTER, currentValues.mcFilter);
      sendCC(MC_CH, MC_CC_ACTIVITY, currentValues.mcActivity);

      // Send NightSky (Ch 2)
      sendCC(NS_CH, NS_CC_MIX, currentValues.nsMix);
      sendCC(NS_CH, NS_CC_DECAY, currentValues.nsDecay);
      sendCC(NS_CH, NS_CC_FILTER, currentValues.nsFilter);
      sendCC(NS_CH, NS_CC_SHIMMER, currentValues.nsShimmer);
    }
  }
}, 25);

function updateUI() {
  dom.valMcMix.innerHTML = `${Math.round((currentValues.mcMix / 127) * 100)}<span>%</span>`;
  dom.valMcSpace.innerHTML = `${Math.round((currentValues.mcSpace / 127) * 100)}<span>%</span>`;
  dom.valMcFilter.innerHTML = `${Math.round(currentValues.mcFilter)}`;
  dom.valMcActivity.innerHTML = `${Math.round(currentValues.mcActivity)}`;

  dom.valNsMix.innerHTML = `${Math.round((currentValues.nsMix / 127) * 100)}<span>%</span>`;
  dom.valNsDecay.innerHTML = `${Math.round(currentValues.nsDecay)}`;
  dom.valNsFilter.innerHTML = `${Math.round(currentValues.nsFilter)}`;
  dom.valNsShimmer.innerHTML = `${Math.round(currentValues.nsShimmer)}`;

  const keys = ['McMix', 'McSpace', 'McFilter', 'McActivity', 'NsMix', 'NsDecay', 'NsFilter', 'NsShimmer'];
  keys.forEach(k => {
    const prop = k.charAt(0).toLowerCase() + k.slice(1);
    dom[`slider${k}`].value = currentValues[prop];
    dom[`act${k}`].style.width = `${(currentValues[prop] / 127) * 100}%`;
  });
}

// User slider inputs
const manualMap = {
  McMix: { ch: MC_CH, cc: MC_CC_MIX, prop: 'mcMix' },
  McSpace: { ch: MC_CH, cc: MC_CC_SPACE, prop: 'mcSpace' },
  McFilter: { ch: MC_CH, cc: MC_CC_FILTER, prop: 'mcFilter' },
  McActivity: { ch: MC_CH, cc: MC_CC_ACTIVITY, prop: 'mcActivity' },
  NsMix: { ch: NS_CH, cc: NS_CC_MIX, prop: 'nsMix' },
  NsDecay: { ch: NS_CH, cc: NS_CC_DECAY, prop: 'nsDecay' },
  NsFilter: { ch: NS_CH, cc: NS_CC_FILTER, prop: 'nsFilter' },
  NsShimmer: { ch: NS_CH, cc: NS_CC_SHIMMER, prop: 'nsShimmer' }
};

Object.keys(manualMap).forEach(key => {
  const item = manualMap[key];
  dom[`slider${key}`].addEventListener('input', (e) => {
    currentValues[item.prop] = parseFloat(e.target.value);
    targetValues[item.prop] = currentValues[item.prop];
    updateUI();
    sendCC(item.ch, item.cc, currentValues[item.prop]);
  });
});

enableBtn.addEventListener('click', () => {
  isEnabled = !isEnabled;
  if (isEnabled) {
    isPaused = false;
    enableBtn.classList.add('running');
    enableIcon.innerText = '◼';
    enableLabel.innerText = 'Stop Dual Follow';
    pauseBtn.innerText = '⏸ Pause';
    hudEngine.innerText = 'Active: Microcosm (Ch1) + NightSky (Ch2) Following';
  } else {
    enableBtn.classList.remove('running');
    enableIcon.innerText = '▶';
    enableLabel.innerText = 'Enable Dual Follow';
    hudEngine.innerText = 'Dual Automation Stopped';
  }
});

pauseBtn.addEventListener('click', () => {
  if (!isEnabled) return;
  isPaused = !isPaused;
  if (isPaused) {
    pauseBtn.innerText = '▶ Resume';
    hudEngine.innerText = 'Paused: Dual Pedal Parameters Frozen';
  } else {
    pauseBtn.innerText = '⏸ Pause';
    hudEngine.innerText = 'Resumed Dual Automation';
  }
});

restoreBtn.addEventListener('click', () => {
  currentValues = { ...defaultSnapshot };
  targetValues = { ...defaultSnapshot };
  updateUI();
  sendCC(MC_CH, MC_CC_MIX, defaultSnapshot.mcMix);
  sendCC(MC_CH, MC_CC_SPACE, defaultSnapshot.mcSpace);
  sendCC(MC_CH, MC_CC_FILTER, defaultSnapshot.mcFilter);
  sendCC(MC_CH, MC_CC_ACTIVITY, defaultSnapshot.mcActivity);

  sendCC(NS_CH, NS_CC_MIX, defaultSnapshot.nsMix);
  sendCC(NS_CH, NS_CC_DECAY, defaultSnapshot.nsDecay);
  sendCC(NS_CH, NS_CC_FILTER, defaultSnapshot.nsFilter);
  sendCC(NS_CH, NS_CC_SHIMMER, defaultSnapshot.nsShimmer);
  hudEngine.innerText = 'Restored starting dual snapshots';
});

initWebSocket();
updateUI();
