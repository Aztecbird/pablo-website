==========================================================
 MICROCOSM AI — Adaptive Performance Companion for Mac
 Created by Pablo Arellano
 https://www.pabloarellano.org
==========================================================

Thank you for your support!

HOW TO LAUNCH:
1. Double-click "Microcosm AI.app" (or double-click "start.command").
2. Your web browser will open automatically to the companion dashboard at:
   http://localhost:3880
3. Select your MIDI interface connected to Hologram Microcosm under "Pedal Out".
4. Select your keyboard under "Keys In".
5. Click "Enable Follow" and perform!

REQUIREMENTS:
- macOS 11 (Big Sur) or newer (Intel & Apple Silicon M1/M2/M3/M4 supported).
- Hologram Microcosm pedal connected via standard 5-pin DIN MIDI.
- A MIDI keyboard or controller.

SUPPORT & QUESTIONS:
Email: aztecbird@mac.com
Website: https://www.pabloarellano.org
==========================================================
