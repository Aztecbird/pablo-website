#!/usr/bin/env python3
"""
===============================================================================
DUST Ambient Stem Generator (Python 3 - Zero Dependencies)
===============================================================================
Procedurally generates coordinated 8-stem ambient sound packs for Soundmorph DUST.
Each stem is tailored for one of DUST's 8 granular particle emitters.

Requires: Python 3.6+ (No external libraries required; uses pure standard library)
===============================================================================
"""

import sys
import os
import math
import wave
import struct
import random
import time
import argparse

SAMPLE_RATE = 48000

# Note to frequency (A4 = 440 Hz)
NOTE_NAMES = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"]

def note_to_freq(note_name, octave):
    note_upper = note_name.upper().replace("DB", "C#").replace("EB", "D#").replace("GB", "F#").replace("AB", "G#").replace("BB", "A#")
    if note_upper not in NOTE_NAMES:
        note_upper = "C"
    idx = NOTE_NAMES.index(note_upper)
    midi_note = (octave + 1) * 12 + idx
    return 440.0 * (2.0 ** ((midi_note - 69) / 12.0))

# Preset Mood Definitions (Intervals & Textures)
MOODS = {
    "ethereal": {
        "scale": [0, 2, 4, 6, 7, 9, 11],  # Lydian
        "desc": "Bright, shimmering glass, suspended cosmic chords",
        "speed": 0.5
    },
    "dark_scifi": {
        "scale": [0, 1, 3, 5, 7, 8, 10],  # Phrygian
        "desc": "Deep menacing sub-drones, tension textures, industrial wind",
        "speed": 0.4
    },
    "cosmic_drone": {
        "scale": [0, 2, 4, 7, 9],         # Major Pentatonic
        "desc": "Deep space resonance, harmonically aligned drones",
        "speed": 0.3
    },
    "meditation": {
        "scale": [0, 2, 5, 7, 9],         # Sus2/Sus4 Floating
        "desc": "Peaceful organic hums, soft bell strikes, warm pads",
        "speed": 0.6
    },
    "cyberpunk": {
        "scale": [0, 2, 3, 5, 7, 9, 10],  # Dorian
        "desc": "Gritty low-end, micro-clicks, resonant filter sweeps",
        "speed": 0.7
    }
}

def clamp(val, min_val=-1.0, max_val=1.0):
    return max(min_val, min(max_val, val))

def write_wav(filename, samples_left, samples_right, sample_rate=48000):
    """Writes a 16-bit 48kHz stereo WAV file."""
    num_samples = len(samples_left)
    max_amp = 0.0001
    for i in range(num_samples):
        al = abs(samples_left[i])
        ar = abs(samples_right[i])
        if al > max_amp: max_amp = al
        if ar > max_amp: max_amp = ar
    
    # Normalize to -1.0 dB (~0.89 max amplitude) to prevent clipping
    gain = 0.89 / max_amp if max_amp > 0 else 1.0

    with wave.open(filename, 'w') as wav_file:
        wav_file.setnchannels(2)       # Stereo
        wav_file.setsampwidth(2)      # 16-bit
        wav_file.setframerate(sample_rate)
        
        frames = bytearray()
        fade_len = int(sample_rate * 0.5)
        for i in range(num_samples):
            # Apply fade in/out (0.5 sec) to guarantee smooth looping
            env = 1.0
            if i < fade_len:
                env = 0.5 * (1.0 - math.cos(math.pi * i / fade_len))
            elif i > num_samples - fade_len:
                env = 0.5 * (1.0 - math.cos(math.pi * (num_samples - i) / fade_len))

            val_l = int(clamp(samples_left[i] * gain * env) * 32767)
            val_r = int(clamp(samples_right[i] * gain * env) * 32767)
            frames.extend(struct.pack('<hh', val_l, val_r))
            
        wav_file.writeframes(frames)

# -----------------------------------------------------------------------------
# 8 Dedicated Audio Stem Generators for DUST Emitters
# -----------------------------------------------------------------------------

def gen_stem_1_sub_drone(root_freq, duration_sec, mood):
    """Emitter 1: Deep Sub Drone with slow harmonic beating."""
    num_samples = int(SAMPLE_RATE * duration_sec)
    left = [0.0] * num_samples
    right = [0.0] * num_samples
    f0 = root_freq * 0.5 # Deep bass (1 octave down)
    
    for i in range(num_samples):
        t = i / SAMPLE_RATE
        detune = 0.15 * math.sin(2 * math.pi * 0.05 * t)
        lfo = 0.8 + 0.2 * math.sin(2 * math.pi * 0.1 * t)
        
        s_fund = math.sin(2 * math.pi * f0 * t)
        s_harm2 = 0.4 * math.sin(2 * math.pi * (f0 * 2.0 + detune) * t)
        s_harm3 = 0.15 * math.sin(2 * math.pi * (f0 * 3.0 - detune) * t)
        s_sub = 0.5 * math.sin(2 * math.pi * (f0 * 0.5) * t)
        
        sig = (s_fund + s_harm2 + s_harm3 + s_sub) * lfo
        left[i] = sig * (1.0 + 0.1 * math.sin(2 * math.pi * 0.08 * t))
        right[i] = sig * (1.0 - 0.1 * math.sin(2 * math.pi * 0.08 * t))
    return left, right

def gen_stem_2_harmonic_pad(root_freq, duration_sec, mood):
    """Emitter 2: Evolving Chordal Harmonic Pad."""
    num_samples = int(SAMPLE_RATE * duration_sec)
    left = [0.0] * num_samples
    right = [0.0] * num_samples
    scale = mood["scale"]
    
    intervals = [scale[0], scale[2 % len(scale)], scale[4 % len(scale)], scale[6 % len(scale)]]
    freqs = [root_freq * (2.0 ** (semi / 12.0)) for semi in intervals]
    
    for idx, f in enumerate(freqs):
        pan = -0.6 + (1.2 / len(freqs)) * idx
        l_gain = math.sqrt(0.5 * (1.0 - pan))
        r_gain = math.sqrt(0.5 * (1.0 + pan))
        phase_lfo_speed = 0.05 + 0.03 * idx
        
        for i in range(num_samples):
            t = i / SAMPLE_RATE
            mod = 1.0 + 0.003 * math.sin(2 * math.pi * phase_lfo_speed * t)
            lfo_amp = 0.6 + 0.4 * math.sin(2 * math.pi * (phase_lfo_speed * 1.5) * t + idx)
            sig = (math.sin(2 * math.pi * f * mod * t) + 
                   0.3 * math.sin(2 * math.pi * (f * 2) * mod * t)) * lfo_amp
            left[i] += sig * l_gain
            right[i] += sig * r_gain
    return left, right

def gen_stem_3_spectral_shimmer(root_freq, duration_sec, mood):
    """Emitter 3: High-Frequency Glass / Crystal Shimmer."""
    num_samples = int(SAMPLE_RATE * duration_sec)
    left = [0.0] * num_samples
    right = [0.0] * num_samples
    scale = mood["scale"]
    
    high_freqs = [root_freq * 4.0 * (2.0 ** (s / 12.0)) for s in scale[:4]]
    
    for idx, f in enumerate(high_freqs):
        lfo_rate = 0.07 + idx * 0.04
        for i in range(num_samples):
            t = i / SAMPLE_RATE
            swirl = math.sin(2 * math.pi * lfo_rate * t)
            shimmer = math.sin(2 * math.pi * (f + 2.0 * swirl) * t) * (0.5 + 0.5 * swirl)
            left[i] += shimmer * (0.5 + 0.4 * swirl)
            right[i] += shimmer * (0.5 - 0.4 * swirl)
    return left, right

def gen_stem_4_organic_noise_bed(root_freq, duration_sec, mood):
    """Emitter 4: Warm Organic Filtered Noise Texture."""
    num_samples = int(SAMPLE_RATE * duration_sec)
    left = [0.0] * num_samples
    right = [0.0] * num_samples
    
    b0_l, b0_r = 0.0, 0.0
    for i in range(num_samples):
        t = i / SAMPLE_RATE
        nl = random.uniform(-1.0, 1.0)
        nr = random.uniform(-1.0, 1.0)
        
        b0_l = (b0_l + (0.02 * nl)) / 1.02
        b0_r = (b0_r + (0.02 * nr)) / 1.02
        
        left[i] = b0_l * 2.5
        right[i] = b0_r * 2.5
    return left, right

def gen_stem_5_resonant_bells(root_freq, duration_sec, mood):
    """Emitter 5: Stochastic Modal Chimes / Bell Strikes."""
    num_samples = int(SAMPLE_RATE * duration_sec)
    left = [0.0] * num_samples
    right = [0.0] * num_samples
    scale = mood["scale"]
    
    num_strikes = int(duration_sec * 0.8)
    for _ in range(num_strikes):
        strike_t = random.uniform(0.5, duration_sec - 2.0)
        start_idx = int(strike_t * SAMPLE_RATE)
        semi = random.choice(scale) + random.choice([12, 24, 36])
        f = root_freq * (2.0 ** (semi / 12.0))
        pan = random.uniform(-0.8, 0.8)
        lg = math.sqrt(0.5 * (1.0 - pan))
        rg = math.sqrt(0.5 * (1.0 + pan))
        decay_sec = random.uniform(1.2, 3.5)
        
        for k in range(int(decay_sec * SAMPLE_RATE)):
            if start_idx + k >= num_samples: break
            t_decay = k / SAMPLE_RATE
            env = math.exp(-3.0 * t_decay / decay_sec)
            bell_sig = (math.sin(2 * math.pi * f * t_decay) +
                        0.5 * math.sin(2 * math.pi * f * 2.76 * t_decay) +
                        0.25 * math.sin(2 * math.pi * f * 5.4 * t_decay)) * env * 0.4
            left[start_idx + k] += bell_sig * lg
            right[start_idx + k] += bell_sig * rg
            
    return left, right

def gen_stem_6_pitch_drift_texture(root_freq, duration_sec, mood):
    """Emitter 6: Pitch-Drifting Tape / Analog Wow-and-Flutter Voice."""
    num_samples = int(SAMPLE_RATE * duration_sec)
    left = [0.0] * num_samples
    right = [0.0] * num_samples
    f = root_freq * 2.0
    
    phase_l = 0.0
    phase_r = 0.0
    for i in range(num_samples):
        t = i / SAMPLE_RATE
        drift = 1.0 + 0.015 * math.sin(2 * math.pi * 0.3 * t) + 0.005 * math.sin(2 * math.pi * 4.2 * t)
        freq_cur = f * drift
        
        phase_l += (2 * math.pi * freq_cur) / SAMPLE_RATE
        phase_r += (2 * math.pi * (freq_cur * 1.002)) / SAMPLE_RATE
        
        s_l = math.tanh(math.sin(phase_l) + 0.3 * math.sin(phase_l * 2))
        s_r = math.tanh(math.sin(phase_r) + 0.3 * math.sin(phase_r * 2))
        
        left[i] = s_l * 0.7
        right[i] = s_r * 0.7
    return left, right

def gen_stem_7_granular_clicks(root_freq, duration_sec, mood):
    """Emitter 7: Micro-Transients, Tiny Pops & Crackle for Particle Triggers."""
    num_samples = int(SAMPLE_RATE * duration_sec)
    left = [0.0] * num_samples
    right = [0.0] * num_samples
    
    click_density = 12.0
    total_clicks = int(duration_sec * click_density)
    
    for _ in range(total_clicks):
        pos = random.randint(0, num_samples - 500)
        pan = random.uniform(0.1, 0.9)
        amp = random.uniform(0.1, 0.6)
        click_type = random.choice(["pop", "tick", "burst"])
        
        if click_type == "pop":
            freq = random.uniform(800, 3000)
            for k in range(120):
                if pos + k >= num_samples: break
                decay = math.exp(-k / 20.0)
                sig = math.sin(2 * math.pi * freq * (k / SAMPLE_RATE)) * decay * amp
                left[pos + k] += sig * (1.0 - pan)
                right[pos + k] += sig * pan
        else:
            for k in range(40):
                if pos + k >= num_samples: break
                sig = (random.uniform(-1.0, 1.0) * math.exp(-k / 8.0)) * amp
                left[pos + k] += sig * (1.0 - pan)
                right[pos + k] += sig * pan
                
    return left, right

def gen_stem_8_formant_choir(root_freq, duration_sec, mood):
    """Emitter 8: Vocalic / Formant Resonance Sweep."""
    num_samples = int(SAMPLE_RATE * duration_sec)
    left = [0.0] * num_samples
    right = [0.0] * num_samples
    f = root_freq
    
    for i in range(num_samples):
        t = i / SAMPLE_RATE
        f1 = 400.0 + 200.0 * math.sin(2 * math.pi * 0.09 * t)
        f2 = 1200.0 + 400.0 * math.cos(2 * math.pi * 0.07 * t)
        
        carrier = math.sin(2 * math.pi * f * t)
        formant1 = math.sin(2 * math.pi * f1 * t) * 0.5
        formant2 = math.sin(2 * math.pi * f2 * t) * 0.3
        
        vocal = carrier * (formant1 + formant2)
        pan_mod = 0.5 + 0.3 * math.sin(2 * math.pi * 0.12 * t)
        left[i] = vocal * pan_mod
        right[i] = vocal * (1.0 - pan_mod)
        
    return left, right

# -----------------------------------------------------------------------------
# Main Generation Orchestrator
# -----------------------------------------------------------------------------

STEM_GENERATORS = [
    ("emitter_1_sub_drone.wav", "Emitter 1 - Deep Sub Drone", gen_stem_1_sub_drone),
    ("emitter_2_harmonic_pad.wav", "Emitter 2 - Evolving Harmonic Pad", gen_stem_2_harmonic_pad),
    ("emitter_3_spectral_shimmer.wav", "Emitter 3 - High Crystal Shimmer", gen_stem_3_spectral_shimmer),
    ("emitter_4_organic_noise.wav", "Emitter 4 - Filtered Organic Noise Bed", gen_stem_4_organic_noise_bed),
    ("emitter_5_resonant_bells.wav", "Emitter 5 - Stochastic Bell Chimes", gen_stem_5_resonant_bells),
    ("emitter_6_pitch_drift.wav", "Emitter 6 - Pitch-Drift Analog Texture", gen_stem_6_pitch_drift_texture),
    ("emitter_7_granular_clicks.wav", "Emitter 7 - Micro-Transients / Clicks", gen_stem_7_granular_clicks),
    ("emitter_8_formant_choir.wav", "Emitter 8 - Vocalic Formant Sweep", gen_stem_8_formant_choir),
]

def generate_dust_pack(root_note="D", octave=2, mood_name="ethereal", duration=20.0, output_dir=None):
    if mood_name not in MOODS:
        print(f"Unknown mood '{mood_name}'. Falling back to 'ethereal'.")
        mood_name = "ethereal"
        
    mood = MOODS[mood_name]
    root_freq = note_to_freq(root_note, octave)
    
    timestamp = time.strftime("%Y%m%d_%H%M%S")
    pack_name = f"DUST_Pack_{mood_name.upper()}_{root_note}{octave}_{timestamp}"
    
    if output_dir is None:
        base_dir = os.path.join(os.getcwd(), "dust_ambient_packs")
        output_dir = os.path.join(base_dir, pack_name)
    else:
        output_dir = os.path.join(output_dir, pack_name)
        
    os.makedirs(output_dir, exist_ok=True)
    
    print("\n" + "=" * 70)
    print("  ✦ GENERATING DUST 8-EMITTER AMBIENT SOUND PACK ✦")
    print("=" * 70)
    print(f"  • Mood Style : {mood_name.upper()} ({mood['desc']})")
    print(f"  • Root Pitch : {root_note}{octave} ({root_freq:.2f} Hz)")
    print(f"  • Duration   : {duration:.1f} seconds per stem")
    print(f"  • Format     : 16-bit/48kHz Stereo WAV (Seamless Fade Envelopes)")
    print(f"  • Target Dir : {output_dir}")
    print("=" * 70)
    
    for idx, (filename, label, gen_func) in enumerate(STEM_GENERATORS, 1):
        print(f"  [{idx}/8] Rendering {label} ... ", end="", flush=True)
        left, right = gen_func(root_freq, duration, mood)
        filepath = os.path.join(output_dir, filename)
        write_wav(filepath, left, right, SAMPLE_RATE)
        print("✓ Done")
        
    readme_path = os.path.join(output_dir, "HOW_TO_LOAD_INTO_DUST.txt")
    with open(readme_path, "w") as f:
        f.write(f"DUST AMBIENT PACK: {pack_name}\n")
        f.write("=" * 60 + "\n\n")
        f.write("HOW TO USE IN SOUNDMORPH DUST (LOGIC PRO X):\n")
        f.write("1. Open Logic Pro X and insert Soundmorph DUST on a track.\n")
        f.write("2. Drag and drop each of the 8 WAV files into DUST's 8 Emitter slots:\n")
        for i, (fn, desc, _) in enumerate(STEM_GENERATORS, 1):
            f.write(f"   - Emitter {i}: {fn} ({desc})\n")
        f.write("\n3. Set DUST to 'Auto-Sequencer' or play/loop your track.\n")
        f.write("4. Adjust Gravity, Flow Field, and Convolution Reverb to taste.\n")
        
    print("\n✓ ALL 8 STEMS READY! Drag and drop into DUST's 8 emitters.")
    print(f"📁 Output Folder: {output_dir}\n")
    return output_dir

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Generate 8-stem ambient audio packs for Soundmorph DUST.")
    parser.add_argument("--mood", choices=list(MOODS.keys()), default="ethereal", help="Ambient mood style (ethereal, dark_scifi, cosmic_drone, meditation, cyberpunk)")
    parser.add_argument("--key", default="D", help="Root musical key (e.g. C, C#, D, Eb, F#, A)")
    parser.add_argument("--octave", type=int, default=2, help="Octave number (default: 2)")
    parser.add_argument("--duration", type=float, default=20.0, help="Duration in seconds (default: 20)")
    parser.add_argument("--out", default=None, help="Custom output directory")
    
    args = parser.parse_args()
    generate_dust_pack(root_note=args.key, octave=args.octave, mood_name=args.mood, duration=args.duration, output_dir=args.out)
