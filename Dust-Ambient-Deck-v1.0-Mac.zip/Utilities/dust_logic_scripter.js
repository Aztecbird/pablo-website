/*
  =============================================================================
  DUST Ambient Generative Engine & Particle Modulator for Logic Pro Scripter
  =============================================================================
  - Generates stochastic ambient harmonic notes/clusters for DUST emitters.
  - Automatically generates smooth organic MIDI CC automation (CC1, CC11, CC74, CC16)
    to modulate DUST particle gravity, speed, emitter movement, and filtering.
  =============================================================================
*/

var NeedsTimingInfo = true;

var PluginParameters = [
    { name: "Engine Active", type: "menu", valueStrings: ["Off", "On"], defaultValue: 1 },
    { name: "Musical Scale", type: "menu", valueStrings: ["C Minor Aeolian", "C Minor Dorian", "Ethereal Lydian", "Floating Sus2/4", "Pentatonic Shimmer"], defaultValue: 0 },
    { name: "Root Note", type: "menu", valueStrings: ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"], defaultValue: 0 },
    { name: "Density / Frequency", type: "lin", minValue: 1, maxValue: 10, numberOfSteps: 9, defaultValue: 4 },
    { name: "Note Length (Beats)", type: "lin", minValue: 2, maxValue: 32, numberOfSteps: 30, defaultValue: 12 },
    { name: "Octave Range", type: "menu", valueStrings: ["Deep Drone (C1-C3)", "Mid Texture (C2-C5)", "High Shimmer (C4-C6)", "Full Spectrum (C1-C6)"], defaultValue: 3 },
    { name: "DUST CC Modulation", type: "menu", valueStrings: ["Off", "Subtle Drift", "Deep Cosmic Wave", "Chaotic Flux"], defaultValue: 2 }
];

var SCALES = [
    [0, 2, 3, 5, 7, 8, 10],       // C Minor Aeolian
    [0, 2, 3, 5, 7, 9, 10],       // C Minor Dorian
    [0, 2, 4, 6, 7, 9, 11],       // Lydian
    [0, 2, 5, 7, 9],              // Sus2 / Sus4
    [0, 2, 4, 7, 9]               // Major Pentatonic
];

var OCTAVE_RANGES = [
    [24, 48], // C1 - C3
    [36, 72], // C2 - C5
    [60, 84], // C4 - C6
    [24, 84]  // C1 - C6
];

var activeNotes = [];
var lastBeatEvaluated = -1;
var ccPhase1 = 0.0;
var ccPhase2 = 0.0;
var ccPhase3 = 0.0;
var lastCCBeat = -1;

function HandleMIDI(event) {
    event.send();
}

function ProcessMIDI() {
    var timing = GetTimingInfo();
    if (!timing.playing) {
        killAllActiveNotes();
        return;
    }
    
    var isActive = GetParameter("Engine Active");
    if (isActive === 0) {
        killAllActiveNotes();
        return;
    }

    var currentBeat = timing.blockStartBeat;

    // CC Modulation Generator
    var modMode = GetParameter("DUST CC Modulation");
    if (modMode > 0) {
        if (currentBeat - lastCCBeat >= 0.125 || lastCCBeat < 0) {
            lastCCBeat = currentBeat;
            var speedMult = (modMode === 1) ? 0.02 : (modMode === 2) ? 0.05 : 0.12;
            
            ccPhase1 += speedMult;
            ccPhase2 += speedMult * 0.73;
            ccPhase3 += speedMult * 1.41;

            sendCC(1, Math.min(127, Math.max(0, Math.floor(64 + 55 * Math.sin(ccPhase1)))));
            sendCC(11, Math.min(127, Math.max(0, Math.floor(64 + 48 * Math.sin(ccPhase2) + 10 * Math.cos(ccPhase3)))));
            sendCC(74, Math.min(127, Math.max(0, Math.floor(64 + 50 * Math.sin(ccPhase3)))));
            sendCC(16, Math.min(127, Math.max(0, Math.floor(64 + 58 * Math.cos(ccPhase1 * 0.5)))));
        }
    }

    // Ambient Note Spawner
    var stepBeat = Math.floor(currentBeat * 2) / 2;
    if (stepBeat !== lastBeatEvaluated) {
        lastBeatEvaluated = stepBeat;
        cleanupExpiredNotes(currentBeat);

        var density = GetParameter("Density / Frequency");
        var triggerProbability = (density / 10.0) * 0.45;

        if (Math.random() < triggerProbability) {
            spawnAmbientNote(currentBeat);
            if (Math.random() < 0.35) {
                spawnAmbientNote(currentBeat + 0.1);
            }
        }
    }
}

function spawnAmbientNote(startBeat) {
    var scaleIdx = GetParameter("Musical Scale");
    var rootNote = GetParameter("Root Note");
    var octaveIdx = GetParameter("Octave Range");
    var noteLengthBeats = GetParameter("Note Length (Beats)");
    
    var scale = SCALES[scaleIdx];
    var octaveBounds = OCTAVE_RANGES[octaveIdx];

    var candidateNotes = [];
    for (var note = octaveBounds[0]; note <= octaveBounds[1]; note++) {
        var semitone = (note - rootNote) % 12;
        if (semitone < 0) semitone += 12;
        if (scale.indexOf(semitone) !== -1) {
            candidateNotes.push(note);
        }
    }

    if (candidateNotes.length === 0) return;

    var pitch = candidateNotes[Math.floor(Math.random() * candidateNotes.length)];
    var velocity = Math.floor(40 + Math.random() * 55); 
    var duration = noteLengthBeats * (0.75 + Math.random() * 0.5);

    var noteOn = new NoteOn();
    noteOn.pitch = pitch;
    noteOn.velocity = velocity;
    noteOn.send();

    activeNotes.push({ pitch: pitch, offBeat: startBeat + duration });
}

function cleanupExpiredNotes(currentBeat) {
    var remainingNotes = [];
    for (var i = 0; i < activeNotes.length; i++) {
        var n = activeNotes[i];
        if (currentBeat >= n.offBeat) {
            var noteOff = new NoteOff();
            noteOff.pitch = n.pitch;
            noteOff.velocity = 64;
            noteOff.send();
        } else {
            remainingNotes.push(n);
        }
    }
    activeNotes = remainingNotes;
}

function killAllActiveNotes() {
    for (var i = 0; i < activeNotes.length; i++) {
        var noteOff = new NoteOff();
        noteOff.pitch = activeNotes[i].pitch;
        noteOff.velocity = 0;
        noteOff.send();
    }
    activeNotes = [];
}

function sendCC(num, val) {
    var cc = new ControlChange();
    cc.number = num;
    cc.value = val;
    cc.send();
}
