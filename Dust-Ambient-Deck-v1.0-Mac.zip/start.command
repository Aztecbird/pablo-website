#!/bin/bash
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd "$DIR"

PORT=8082
lsof -ti :$PORT | xargs kill -9 2>/dev/null

echo "=========================================================="
echo " 🌌 DUST AMBIENT DECK — Pablo Arellano"
echo " https://www.pabloarellano.org"
echo "=========================================================="
echo "Launching local server on port $PORT..."

(sleep 1.2 && open "http://localhost:$PORT") &

if [ -f "index.html" ]; then
    SERVE_DIR="$DIR"
else
    SERVE_DIR="$DIR/DUST Ambient Deck.app/Contents/Resources"
fi

if command -v python3 >/dev/null 2>&1; then
    python3 -m http.server $PORT --directory "$SERVE_DIR"
elif command -v python >/dev/null 2>&1; then
    python -m SimpleHTTPServer $PORT
elif command -v node >/dev/null 2>&1; then
    node -e "const http=require('http'),fs=require('fs'),path=require('path');http.createServer((req,res)=>{let f=path.join('$SERVE_DIR',req.url==='/'?'index.html':req.url);if(fs.existsSync(f)){res.writeHead(200,{'Content-Type':f.endsWith('.html')?'text/html':f.endsWith('.js')?'application/javascript':'text/plain'});fs.createReadStream(f).pipe(res)}else{res.writeHead(404);res.end()}}).listen($PORT);"
fi
