=============================================================================
 DUST AMBIENT DECK — Soundmorph DUST & Arturia Efx FRAGMENTS Companion
 Created by Pablo Arellano
 Website: https://www.pabloarellano.org
 Support & Inquiries: aztecbird@mac.com
=============================================================================

Thank you for supporting this release!

QUICKSTART (MAC):
1. Double-click "DUST Ambient Deck.app" (or double-click "start.command").
2. Your browser will launch automatically at:
   http://localhost:8082
3. Select your MIDI Output (e.g., "IAC Driver Bus 1") in the top-right menu.
4. Open Logic Pro X with Soundmorph DUST and Arturia Efx FRAGMENTS inserted.
5. Explore the interactive preset library, use the Live XY Pad to morph particle
   speed & gravity, or trigger latching C-Minor chords and drones.

WHAT IS INCLUDED IN THIS PACKAGE:
- DUST Ambient Deck.app (Standalone macOS double-clickable app bundle)
- start.command (One-click double-clickable terminal-free launcher)
- Presets/DUST (30 complete .aupreset files ready for Soundmorph DUST):
  * antigrav 1–8: Evolving cinematic, glass shimmer, and granular glitch.
  * antigrav 9–19: C-Minor relaxing soundscapes anchored with deep C Drones.
  * antigrav 20–30: Aperiodic anti-loop particle flows with infinite reverbs.
- Presets/Efx_FRAGMENTS (20 complete .aupreset files for Arturia Efx FRAGMENTS):
  * antigrav fx 1–10: Lush clouds, sacred cathedral blooms, and pitch shimmers.
  * antigrav fx 11–20: Long granular stretch diffusions and tape smears.
- Utilities/dust_logic_scripter.js (Logic Pro Scripter JavaScript engine)
- Utilities/dust_gen.py (Standalone Python 8-stem ambient WAV synthesizer)

PRESET INSTALLATION LOCATIONS (FOR LOGIC PRO X):
If you want to install or re-install the AU presets manually:
- Copy Presets/DUST/*.aupreset to:
  ~/Library/Audio/Presets/SoundMorph/Dust/
- Copy Presets/Efx_FRAGMENTS/*.aupreset to:
  ~/Library/Audio/Presets/Arturia/Efx FRAGMENTS/

DAW SIGNAL CHAIN RECOMMENDATION (LOGIC PRO X):
[ MIDI FX ]   ─► Logic Scripter (dust_logic_scripter.js)
     │
[ Instrument] ─► Soundmorph DUST (Preset: antigrav 9–30 in C Minor)
     │
[ Audio FX ]  ─► Arturia Efx FRAGMENTS (Preset: antigrav fx 1–20)

SUPPORT & INQUIRIES:
Email: aztecbird@mac.com
Website: https://www.pabloarellano.org
=============================================================================
